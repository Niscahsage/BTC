<?php
session_start();

// initializing variables
//$username = "";
//$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('149.56.96.102', 'bitstuto_zukbits', '5c{EBU!VoHUm', 'bitstuto_schooldb');
 
// $servername = "149.56.96.102";
//$username = "bitstuto_zukbits";
//$password = "5c{EBU!VoHUm";
//$dbname = "bitstuto_schooldb";

//var_dump($servername, $username, $password, $dbname);

//$conn = mysqli_connect($servername, $username, $password, $dbname);
 
/**
 * mysql_connect is deprecated
 * using mysqli_connect instead
 */
/*
$databaseHost     = 'localhost';
$databaseName     = 'boo';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
*/


// REGISTER USER


// ... 

// LOGIN USER


?>