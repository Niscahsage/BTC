<?php 
require_once('class.phpmailer.php');
//Connect to MSSQL
$servername = "149.56.96.102";
$username = "bitstuto_zukbits";
$password = "5c{EBU!VoHUm";
$database = "bitstuto_schooldb";
$response = file_get_contents('php://input');
//$data = json_decode(file_get_contents('php://input'), true);
$data = json_decode($response,true);

$MerchantRequestID=$data['Body']['stkCallback']['MerchantRequestID'];
$CheckoutRequestID=$data['Body']['stkCallback']['CheckoutRequestID'];
$ResultCode=$data['Body']['stkCallback']['ResultCode'];
$ResultDesc=$data['Body']['stkCallback']['ResultDesc'];

$Amount=$data['Body']['stkCallback']['CallbackMetadata']['Item'][0]['Value'];
$MpesaReceiptNumber=$data['Body']['stkCallback']['CallbackMetadata']['Item'][1]['Value'];
$TransactionDate=$data['Body']['stkCallback']['CallbackMetadata']['Item'][3]['Value'];
$PhoneNumber=$data['Body']['stkCallback']['CallbackMetadata']['Item'][4]['Value'];
$Status = 'hidden';

// Create connection
$conn = new mysqli($servername, $username, $password,$database);
        
$sql = "UPDATE bitschoolpay set MpesaReceiptNumber='$MpesaReceiptNumber',TransactionDate='$TransactionDate',status='$Status' WHERE MerchantRequestID='$MerchantRequestID' && CheckoutRequestID='$CheckoutRequestID'";

if($ResultCode == 0 || $ResultCode == '0'){
    //operation was successful->insert to db
    if ($conn->query($sql) === TRUE) {
        //echo "New record created successfully";
		echo "<script>document.location='https://bitstutorconnect.co.ke/viewlesson.php'</script>";
        
        //upon successful insert into db->post successful.txt
        $log1=fopen('successful',"w");
        fwrite($log1,$response);
        fclose($log1);
        mail('dngwono@gmail.com', 'Mpesa Payment Confirmation', $response);
        mail('nzukipk@gmail.com', 'Mpesa Payment Confirmation', $response);
        
    }
    
}
else{
    //stkpush payment not successful _>post unsuccessful.txt
    echo "An error occurred, please try again";
    $log2=fopen('unsuccessful',"a");
    fwrite($log2, "\n\n=================".date("d-m-Y H:i:s")."=================\n");
    fwrite($log2,$response);
    fclose($log2);
}



$log=fopen('all_replies',"a");
fwrite($log, "\n\n=================".date("d-m-Y H:i:s")."=================\n");
fwrite($log,$response);
fclose($log);

?>