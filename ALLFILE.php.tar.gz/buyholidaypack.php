<?php

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="icon" type="image/jpeg" href="assets/images/btc.PNG">

    <title>BTC: Let's learn digitally!</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-onix-digital.css">
    <link rel="stylesheet" href="assets/css/animated.css">
    <link rel="stylesheet" href="assets/css/owl.css">
<style>
.dropbtn {
  background-color: #ff695f;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
  </head>

    <body>
  <!-- ***** Preloader Start ***** -->
  <!--<div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>-->
  <!-- ***** Preloader End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="index.php" class="logo">
              <img src="assets/images/btc.PNG">
            </a>

            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li class="scroll-to-section"><a href="index.php" class="active">Home</a></li> 
              <li class="scroll-to-section"><div class="dropdown"><button class="dropbtn">Go to Class</button><div class="dropdown-content"><a href="advancedclasses.php">Advanced</a></div></div></li>
            </ul>
            
            <a class='menu-trigger'>
                <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div id="contact" class="contact-us section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 align-self-center">
          <form id="contact" action="buypack.php" method="POST">
            <div class="row">
              <div class="col-lg-12">
                <fieldset>
                  <input type="name" name="name" id="name" placeholder="Your Name" onchange="upperCase()" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="text"  name="phone_number" id="phone_number" placeholder="Your Phone Number in format 0721*****9" maxlength="10" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                  <select name="cat" id="cat" required>
                      <option value=''>Select Category</option>
                      <option value='BtcLite'>BtcLite (50 lessons @1000)</option>
					  <option value='Bronze'>Bronze (100 lessons @1500)</option>
                  </select>
              </div>
              
              <div class="col-lg-12">
                  <br/>
                  <br/>
                <fieldset>
                  <div>
                      <p><b>Click Subscribe</b> below and ensure your phone is on to complete the payment process.</p>
                  </div><br/>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <button type="submit" id="form-submit" class="main-button">Subscribe</button>
                </fieldset>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <div class="footer-dec">
    <img src="assets/images/footer-dec.png" alt="">
  </div>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <div class="about footer-item">
            <div class="logo">
              <a href="#"><img src="assets/images/btc.PNG" alt="Onix Digital TemplateMo"></a>
            </div>
            <a href="mailto:info@bitstutorconnect.co.ke">info@bitstutorconnect.co.ke</a>
            <ul>
              <li><a href="https://web.facebook.com/BitsOnlineSchool/" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <!--<li><a href="/bitsonlineschool"><i class="fa fa-twitter"></i></a></li>
              <li><a href="/bitsonlineschool"><i class="fa fa-youtube"></i></a></li>-->
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <!--<div class="services footer-item">
            <h4>Services</h4>
            <ul>
              <li><a href="elementaryclasses.php">Elementary School Content</a></li>
              <li><a href="advancedclasses.php">Advanced School Content</a></li>
            </ul>
          </div>-->
        </div>
        <div class="col-lg-3">
          <!--<div class="community footer-item">
            <h4>Community</h4>
            <ul>
              <li><a href="#">Schemes of Work</a></li>
              <li><a href="#">Q & A</a></li>
            </ul>
          </div>-->
        </div>
        <div class="col-lg-3">
          <!--<div class="subscribe-newsletters footer-item">
            <h4>Subscribe Newsletters</h4>
            <p>Get our latest news and ideas to your inbox</p>
            <form action="#" method="get">
              <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
              <button type="submit" id="form-submit" class="main-button "><i class="fa fa-paper-plane-o"></i></button>
            </form>
          </div>-->
        </div>
        <div class="col-lg-12">
          <div class="copyright">
            <p>Copyright © <?php echo date('Y');?> Bits TutorConnect. All Rights Reserved. 
            <br></p>
          </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Scripts -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/animation.js"></script>
  <script src="assets/js/imagesloaded.js"></script>
  <script src="assets/js/custom.js"></script>

  <script>
  // Acc
    $(document).on("click", ".naccs .menu div", function() {
      var numberIndex = $(this).index();

      if (!$(this).is("active")) {
          $(".naccs .menu div").removeClass("active");
          $(".naccs ul li").removeClass("active");

          $(this).addClass("active");
          $(".naccs ul").find("li:eq(" + numberIndex + ")").addClass("active");

          var listItemHeight = $(".naccs ul")
            .find("li:eq(" + numberIndex + ")")
            .innerHeight();
          $(".naccs ul").height(listItemHeight + "px");
        }
    });
  </script>
  <script>
function upperCase() {
  const x = document.getElementById("name");
  x.value = x.value.toUpperCase();
}
</script>
</body>
</html>