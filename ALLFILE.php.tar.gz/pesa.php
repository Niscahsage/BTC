<?php
//if(isset($_POST['submit'])) {

  ///$ConsumerKey = 'EgYOPn18Yhbk1eb6j84GvwbZCkaRs90G';
  ///$ConsumerSecret = 'hqwbsm6RfC8Gi2nY';
  
  $ConsumerKey = "H6lC1hgPWGF0iPtS0Z4BQpzXGmiQ4MUfy9Aj8kCaGyiQH1X3";
  $ConsumerSecret = "8XylJ5muPF0GSS5RnOtGTuHqQ8GgmYztTzs42ATx2i4pqBvRalnhciC7raBweirk";

  $Headers =['Content-Type:application/json; charset=utf8'];

  $access_token_url = 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
  ///$access_token_url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

  $curl = curl_init($access_token_url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, $Headers);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
  curl_setopt($curl, CURLOPT_HEADER, FALSE);
  curl_setopt($curl, CURLOPT_USERPWD, $ConsumerKey.":".$ConsumerSecret);

  $result = curl_exec($curl);
  $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
  $Result = json_decode($result);
  $accesstoken = $Result->access_token;
  
  //echo $accesstoken;

$lipa_url = 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
///$lipa_url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

///$BusinessShortCode = '840989';
$BusinessShortCode = '4140371';
$Timestamp = date('YmdHis');
// $PartyA = '254706434259';

$phone='254721850599';
//$phoneaa=$profile->id;
//$exdate=$profile->expiry_date;
$phone =  ltrim($phone, '+');

$pData = [
    'id' => $phone
];

$pquery = http_build_query($pData); 

//$phone="254723737748";
//$email=$profile->mobileNumber;
$PartyA = $phone;
$CallBackURL = 'https://www.bitstutorconnect.co.ke/pay/myparse.php?'.$pquery;

//echo $CallBackURL;
//die();
$AccountReference = 'BITSTUTOR';
$TransactionDesc = 'BITSTUTOR';
///$Passkey = 'e160d1057c1eb23a9e61b9f2d66c5c28fb3efe645a56a437e6d1e03a116d1158';
$Passkey = "656c110446b951a8f402ec4988ec8c58b05c5014eabd38a8e5b37273f139874a";

$Password = base64_encode($BusinessShortCode.$Passkey.$Timestamp);
//$Amount = $_GET["Amount"];
//$Amount = $_GET['Amount'];
//$_SESSION["amount"] = $Amount;


$Amount = 10;//$_GET["Amount"];
$_SESSION["amount"] = 1;
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $lipa_url);
$lipa_header =['Content-Type:application/json','Authorization:Bearer '.$accesstoken];
curl_setopt($curl, CURLOPT_HTTPHEADER,$lipa_header); //setting custom header


$curl_post_data = array(
  //Fill in the request parameters with valid values
  'BusinessShortCode' => $BusinessShortCode,
  'Password' => $Password,
  'Timestamp' => $Timestamp,
  'TransactionType' => 'CustomerPayBillOnline',
  'Amount' => $Amount,
  'PartyA' => $PartyA,
  'PartyB' => $BusinessShortCode,
  'PhoneNumber' => $PartyA,
  'CallBackURL' => $CallBackURL,
  'AccountReference' => $AccountReference,
  'TransactionDesc' => $TransactionDesc
);

//echo $curl_post_data."sdfsdfsd";
//die();
$data_string = json_encode($curl_post_data);

curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);

$curl_response = curl_exec($curl);

        $log1=fopen('reslog',"w");
        fwrite($log1,$curl_response);
        fclose($log1);


// checking curl response 
if ($curl_response === false) {
    // cURL execution failed
    echo 'cURL Error: ' . curl_error($curl);
} else {
    // cURL execution was successful
    // You can check the HTTP status code (e.g., 200 for success) using $status
    if ($status === 200) {
        echo 'cURL request was successful';
        // You can also process the response in $curl_response here
    } else {
        echo 'HTTP Error: ' . $status;
        // Handle HTTP errors here
    }
}

// Close the cURL session
curl_close($curl);

?>