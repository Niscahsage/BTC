<php ?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8" />

<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<link rel="stylesheet" href="style.css" />

<title>Bits Tutor Connect</title>
<style>
* {
  box-sizing: border-box;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 33.33%;
  padding: 10px;
 /* height: 300px;  Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
}
</style>

</head>

<body>

<nav class="navbar">

<!-- LOGO -->

<div class="logo">BOS</div>

<!-- NAVIGATION MENU -->

<ul class="nav-links">

<!-- USING CHECKBOX HACK -->

<input type="checkbox" id="checkbox_toggle" />

<label for="checkbox_toggle" class="hamburger">&#9776;</label>

<!-- NAVIGATION MENUS -->

<div class="menu">

<li><a href="/bitsonlineschool">Home</a></li>

<li><a href="/bitsonlineschool">About</a></li>

<li class="services">Go to Class

<!-- DROPDOWN MENU -->

<ul class="dropdown">

<li><a href="/bitsonlineschool">Primary School </a></li>

<li><a href="/bitsonlineschool/advancedclasses.php">Secondary School</a></li>

</ul>

</li>

<li><a href="/bitsonlineschool">Pricing</a></li>

<li><a href="/bitsonlineschool">Contact</a></li>

</div>

</ul>

</nav>
    <div class="row">
    <div class="col-lg-12">
        <div class="col-lg-4">
            <iframe id="myVideo" src="/bitsonlineschool/Thinktwice.mp4?controls=0" width="576" height="324" frameborder="0" allowfullscreen></iframe>
            
        </div>
        <div class="col-lg-4">
    <video id="myVideo">
        <source src="https://cdn.muse.ai/u/U2fh56h/eb236930b4aa7804b930e2c75bbf4844347043a68b19c7cf020656314d91843d/videos/video.mp4" type="video/mp4">
    </video>
        </div>
        
        <div class="col-lg-4">
    <video id="myVideo">
        <source src="https://cdn.muse.ai/u/U2fh56h/eb236930b4aa7804b930e2c75bbf4844347043a68b19c7cf020656314d91843d/videos/video.mp4" type="video/mp4">
    </video>
        </div>
    </div>
</div>
    <di class="col-lg-12">
        <div class="row">
                <div class="column" style="background-color:#fff; padding-left:15px">
                    <h2>WELCOME TO BTC!</h2>
                    <p>
                      BTC is a digitally enabled learning platform that serves to link learners the best tutors most conveniently, digitally. We exist to ensure unlimited access to curriculum materials for both Basic and Advanced learning.<br/> Our aim is to make learning accessible and affordable to every learner irrespective of their economic background, speed of learning or level of staffing in their schools.<br/>Access to our to our content is rock-bottom cheap, quick and unlimited on every digitally enabled gadget.<br/>Our tutors are all certified teachers sourced from diverse experiences and backgrounds and learners can access their lessons at their most convenience; at home, school, in the car or hospital.<br/>We simply are here to remove any boundaries to good learner-tutor experience!
                  </p>
                </div>
                <div class="column" style="background-color:#bbb;">
                    <h2>Column 2</h2>
                    <p>Some text..</p>
                </div>
                <div class="column" style="background-color:#ccc;">
                    <h2>Column 3</h2>
                    <p>Some text..</p>
                </div>
        </div>
    </di>
                

</body>
<script type='text/javascript'>

    document.getElementById('myVideo').addEventListener('ended', function(e) {

        alert('The End');

    })

</script>

</html>