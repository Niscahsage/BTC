document.addEventListener('DOMContentLoaded', function() {
    const button = document.getElementById('showPopupButton');
    const inputField = document.getElementById('inputField');

    button.addEventListener('click', function() {
        const inputValue = inputField.value;
        alert(inputValue);
    });
});
