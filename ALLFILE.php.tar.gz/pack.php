<?php
 header('Access-Control-Allow-Origin: *'); 
    header("Access-Control-Allow-Credentials: true");
    header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');//  
    header('Access-Control-Max-Age: 1000');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
   $params = file_get_contents('php://input');
   
       require_once('subMpesa.php');
    $mpesa = (new BitMpesa())->initiateStk();
    $pamData = json_decode($mpesa,true);
    
    //echo "<script>document.location='paid.php'</script>";
    
               //Connect to MSSQL
               
        $servername = "localhost";//"149.56.96.102";
$username = "bitstuto";
$password = "w7Sj2nXb65J?";
$dbname = "bitstuto_schooldb";

       $phoneNumber =$_REQUEST['phone_number'];
       if(mb_substr($phoneNumber, 0, 3)!= 254)
       {
           $PhoneNumber = '254'.($phoneNumber * 1); 
       }
       else
       {
          $PhoneNumber =  $phoneNumber;
       }
       
       $category = $_REQUEST['cat'];
       if($category == "Home Schoolers")
       {
		              		// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
    	$sqlqry = "SELECT amount FROM charges WHERE id=11";
  		$sendDtls = $conn->query($sqlqry);
  		$data_array = $sendDtls->fetch_assoc();
           $Amount = $data_array['amount'];
           $Category = 5;
       }
		else
       {
           		// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
    	$sqlqry = "SELECT amount FROM charges WHERE id=10";
  		$sendDtls = $conn->query($sqlqry);
  		$data_array = $sendDtls->fetch_assoc();
           $Amount = $data_array['amount'];
           $Category = 4;
       }

       $Name = $_REQUEST['name'];
	   $Email = $_REQUEST['emailaddress'];
       $TransactionDesc = $PhoneNumber;
       $TransactionDate='';
       $RequestDate = '';
       $StartDate = '';
       $EndDate = '';
       $UserCode = '';
       $MerchantRequestID = $pamData['MerchantRequestID'];
       $CheckoutRequestID = $pamData['CheckoutRequestID'];
       $MpesaReceiptNumber = '';
       $ResultCode = "0";//$pamData['ResultCode'];
       $Processed = '0';
       $ResultDesc = "Request accepted for processing";//$pamData['ResultDesc'];
       
       // Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);

    $sqlqry = "SELECT Name,PhoneNumber,UserCode FROM subscriptions WHERE Category='$Category' && PhoneNumber='$PhoneNumber'";

  $sendDtls = $conn->query($sqlqry);
  $data_array = $sendDtls->fetch_assoc();

// query db first for existence of record

  if(empty($data_array['UserCode']))
  {      

    

       
       // Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);

        $sql = "INSERT INTO subscriptions (PhoneNumber,Name,emailaddress,StartDate,EndDate,Amount,Category,MerchantRequestID,CheckoutRequestID,ResultCode,ResultDesc,MpesaReceiptNumber,TransactionDate,TransactionDesc,RequestDate,UserCode,Processed) VALUES ('$PhoneNumber','$Name','$Email','$StartDate','$EndDate','$Amount','$Category','$MerchantRequestID','$CheckoutRequestID','$ResultCode','$ResultDesc','$MpesaReceiptNumber','$TransactionDate','$TransactionDesc','$RequestDate','$UserCode','$Processed')";
        
            if ($conn->query($sql) === TRUE) 
            {
                //echo "<script>alert('Your record has been saved successfully');document.location='pay/paid.php'</script>";
				echo "<script>document.location='packsuccess.php'</script>";
            }
            else
            {
                //echo "Failed to create Record";
				//echo "<script>alert('You are already subscribed to this category. Please try another category');document.location='subscription.php'</script>";
				echo "<script>document.location='packages.php'</script>";
            }
  }
	else
	{
		echo "<script>alert('You are already subscribed to this category. Please try another category');document.location='packages.php'</script>";
	}
  
  //echo $data_array['UserCode'];


            ?>