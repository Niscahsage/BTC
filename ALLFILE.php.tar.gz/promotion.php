<?php
$servername = "localhost";//"149.56.96.102";
$username = "bitstuto";
$password = "w7Sj2nXb65J?";
$dbname = "bitstuto_schooldb";
$conn = mysqli_connect($servername, $username, $password, $dbname);

if($conn->connect_error){die("Connection failed:".
$conn->connect_error);}
$sql = "SELECT name,email FROM client_tbl";
$result = $conn->query($sql);
if($result->num_rows > 0) {
    $users = [];
    while($row = $result->fetch_assoc()){
    $users[] = $row;    }
}
else{ 
    echo "0 results";
}
$conn->close();
function sendEmail($to,$subject,$message){
    $headers = 'From:your_email@examlpe.com'."\r\n".
    'Reply-To;your_email@examlpe.com'."\r\n".
    'x-mAILER: PHP/'.phpversion();
    
    mail($to,$subject,$message,$headers);}
    foreach($users as $user){
        $to = $user['email'];
        $subject = "Hello".$user['name'];
        $message = "Dear".$user['name']; "This is a test email.";
        
        sendEmail("$to,$subject,$message");
    }
    



?>

