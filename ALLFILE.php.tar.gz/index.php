<?php
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" 
          content="width=device-width, 
                   initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      href=
"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity=
"sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link rel="stylesheet"
          href="stylo.css" />
    <link rel="preconnect" 
          href="https://fonts.gstatic.com" />
    <link
      href=
"https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap"
      rel="stylesheet"
    />
    <link rel="icon" type="image/jpeg" href="assets/images/btc.PNG">
    <title>BTC: Let's learn digitally!</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script>
    setTimeout(function() {
    document.getElementById("#myModal");
    $("#myModal").modal('show');
	},3000); // 3 second delay in ms.
</script>
<script>
function myFunction() {
  document.getElementById("#myModal");
   $("#myModal").modal('hide');
}
</script>
  </head>
  <style>
   .container12 {
            display: flex;
            justify-content: center; /* Centers horizontally */
            align-items: center; /* Centers vertically */
            height: 55 px; /* Adjust the height as needed */}
            
           .container102 {
           display: flex;
            justify-content: center; /* Centers horizontally */
            align-items: center; /* Centers vertically */
            height: 55 px; /* Adjust the height as needed */} 
  .responsive {
            width: 100%; /* Occupies the full width of the container */
            height: auto; /* Maintains aspect ratio */
        }
/* Style The Dropdown Button */
.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
  border-radius:10px;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #f1f1f1}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
  display: block;
}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}
</style>
  <body>

  <!--Modal popup-->
<div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content" style="margin-top: 50%; margin-right: 50%">
            <div class="modal-header">
                <button type="button" OnClick="myFunction()" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-header" style="text-align: center">
                <h5 class="col-lg-12">Do you have a subscription with us?</h5>
            </div>
            <div class="col-lg-12">
                <br/>
                    <div class="col-lg-12" style="text-align: center; background-color: green;">
                     <p style="color:white">If Yes, <a style="color:white" href="/client">Click here to access your account</a></p><br/>
                    </div>
                    <hr/>
                    <div class="col-lg-12" style="text-align: center; background-color:red; ">
                        <p style="color:white;">If Not, <a style="color:white" href="subscriptiontype.php">Click here to Subscribe</a></p><br/>
                    </div><br/>
            </div>
        </div>
    </div>
</div>
<!--end of modal popup-->
    <section id="navbar">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
             <img src="assets/images/btc.PNG">
            </a>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" 
               id="navbarSupportedContent">
            <ul class="navbar-nav m-auto">
              <li class="nav-item">
                <a class="nav-link active" 
                   aria-current="page" 
                   href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" 
                   href="services.php">Services</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" 
                   href="about.php">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" 
                   href="product.php">Products</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" 
                   href="holiday.php">Holiday Package</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" 
                   href="subscriptiontype.php">Subscribe</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" 
                   href="viewlesson.php">View Lesson</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" 
                   href="social.php">Contact Us</a>
              </li>
               <li class="nav-item">
                <a class="nav-link" 
                   href="userguide1.php">User Guide</a>
              </li>
              <li>
                <div class="dropdown">
                <button class="dropbtn">Go to Class</button>
                <div class="dropdown-content">
                <a href="advancedclasses.php">Advanced Learning</a>
                
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </section>

    <!-- banner -->
    <section id="banner">
      <div class="container-fluid" id="banner-container">
        <div class="row" id="banner-row">
          
          <div class="responsive" id="banner-col2" style="margin-top:-10px;">
            <img
              class="img-responsive rounded mx-auto d-block"
              src="assets/images/BTC Landing.jpg"
              alt="" />
          </div>
          
          <div class="container12" id="banner-col">
            <!--<p style="background-color:#1C0708; font-size:18px; margin-top:-30px; text-align:center;">
                Vision : To be the learner's most trusted guide towards academic excellence!</p><br/>
                <p style="background-color:white;color:black; font-size:18px; margin-top:-40px; text-align:center;"></p><br/>
                <p style="background-color:#8D272B; font-size:18px; margin-top:-40px;">
                 Mission : We exist to help remove all barriers to quality grades for the learner and their schools by offering a digital solution to their financial and staffing struggles at academics.</p><br/>
                <p style="background-color:white;color:black; font-size:18px; margin-top:-40px; text-align:center;"></p><br/>
                <p style="background-color:green; font-size:18px; margin-top:-40px;">
                Core Values : Quality, Affordability, Digitization</p><br/>-->
                <p style="font-size:20px;">
              Our promise: Quality grades in three months learning from anywhere, digitally on coins!
                </p>
              </div>
            <div class="container102" style="margin-top:30px;">
              <div class="dropdown">
                <button class="dropbtn">Go to Class</button>
                <div class="dropdown-content">
                <a href="advancedclasses.php">Advanced Learning</a>
                </div>
            </div>
          
          
        </div>
      </div>
    </section>

    <!-- footer -->
    <section id="footer">
      <section id="banner">
        <div class="container-fluid" id="banner-container">
          <div class="row" id="banner-row">
              <div class="col-md-4" id="footer-col2">
              <h3>Subscribe To Newsletter</h3>
              <form method="POST" action="newsletter.php" >
                <div class="mb-3">
                  <input
                    type="email"
                    placeholder="Enter Your Email"
                    class="form-control"
                    id="email" name="email"
                    aria-describedby="emailHelp"
                  />
                  <div id="emailHelp" 
                       class="form-text" style="color:white;">
                    At BTC we guarantee safety for your email address.
                  </div>
                </div>
                <button type="submit" 
                        class="btn btn-primary">
                        Submit
                </button>
              </form>
            </div>
            
            <div class="col-md-4" id="footer-col2">
              <h3>Contact Us</h3>
              
<p>Call Us- +254 (0) 722310358</p>

              
<p>Email Us- info@bitstutorconnect.co.ke</p>
<p> Write Us- P.O Box 955-90200, 
Kitui</p>

            </div>
            <div class="col-md-4" id="footer-col1">
              <h3>Important Links</h3>
              <div>
                  <p>
                     <a class="nav-link active" 
                   aria-current="page" 
                   href="index.php">Home</a>
                   <a class="nav-link" 
                   href="services.php">Services</a>
                   <a class="nav-link" 
                   href="about.php">About Us</a>
                   <a class="nav-link" 
                   href="product.php">Products</a>
                   <a class="nav-link" 
                   href="holiday.php">Holiday Package</a>
                   <a class="nav-link" 
                   href="social.php">Contact Us</a>
                    <a class="nav-link" 
                   href="userguide1.php">User Guide</a>
                  </p>
              </div>
            

            </div>

          </div>
        </div>
      </section>
    </section>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script
      src=
"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
      integrity=
"sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
