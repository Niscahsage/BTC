<?php
/////// Update your database login details here /////
//$host_name = "localhost"; // Your host name 
//$database = "bitstuto_demoscad_sc";       // Your database name
//$username = "bitstuto_devuser";            // Your login userid 
//$password = "thepasswordhaschanged";            // Your password 
//////// End of database details of your server //////

$servername = "localhost";
$username = "bitstuto";
$password = "w7Sj2nXb65J?";
$dbname = "bitstuto_schooldb";

//var_dump($servername, $username, $password, $dbname);

$conn = mysqli_connect($servername, $username, $password, $dbname);

//var_dump($conn);

//////// Do not Edit below /////////
//$connection = mysqli_connect($host_name, $username, $password, $database);

/****if (!$conn) {
    echo "Error: Unable to connect to MySQL.<br>";
    echo "<br>Debugging errno: " . mysqli_connect_errno();
    echo "<br>Debugging error: " . mysqli_connect_error();
    exit;
}
else{
    echo "success";
}****/
?>