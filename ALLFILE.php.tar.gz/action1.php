<?php
session_start();
// this file recieves the posted values from signup.php, connects to the database and inserts the data into the table

//First allow all headers and cross origins
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Accesol-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Authorization');
$params = file_get_contents('php://input');

$servername = "localhost";//"149.56.96.102";
$username = "bitstuto";
$password = "w7Sj2nXb65J?";
$dbname = "bitstuto_schooldb";

	$conn = new mysqli($servername,$username,$password,$dbname);
    // declare variables to hold the posted values
    $name = $_REQUEST['name'];
    $phonenumber = $_REQUEST['phonenumber'];
    $emailaddress = $_REQUEST['emailaddress'];
    $feedback = $_REQUEST['feedback'];
    $enquiry = $_REQUEST['enquiry'];
	$mailMess = "Dear $name , 
Thank you for contacting BTC! We shall get back to ou shortly.
BTC: Let's learn digitally!";

   

    // query to insert into the table

    $sql = "INSERT INTO client_tbl (name,phone_number,email,feedback,enquiry) VALUES ('$name','$phonenumber','$emailaddress','$feedback','$enquiry')";
    if($conn->query($sql) === TRUE){
        echo "<script>document.location='index.php'</script>";
    }
    else{
        echo "Your data was not recorded. Please try again later!";
    }

//$mess=  $_SESSION["massage"];

mail($emailaddress,'Feedback Received',$mailMess);

?>