<?php
 header('Access-Control-Allow-Origin: *'); 
    header("Access-Control-Allow-Credentials: true");
    header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');//  
    header('Access-Control-Max-Age: 1000');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
   $params = file_get_contents('php://input');
    
               //Connect to MSSQL
               
       $servername = "localhost";//"149.56.96.102";
$username = "bitstuto";
$password = "w7Sj2nXb65J?";
$dbname = "bitstuto_schooldb";

       $phoneNumber =$_REQUEST['phone_number'];
       if(mb_substr($phoneNumber, 0, 3)!= 254)
       {
           $PhoneNumber = '254'.($phoneNumber * 1); 
       }
       else
       {
          $PhoneNumber =  $phoneNumber;
       }
       
       $Category = $_REQUEST['cat'];

       $Name = $_REQUEST['name'];
       $StartDate = '20'.date(    "ymdhis");
       $EndDate = '';
       $MarketerCode = $_REQUEST['marketer_code'];
    
               //Connect to MSSQL
               
        $servername = "localhost";//"149.56.96.102";
$username = "bitstuto";
$password = "w7Sj2nXb65J?";
$dbname = "bitstuto_schooldb";

       // Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);

        $sql = "INSERT INTO marketinglinks (PhoneNumber,Name,StartDate,Category,MarketerCode) VALUES ('$PhoneNumber','$Name','$StartDate','$Category','$MarketerCode')";
        
            if ($conn->query($sql) === TRUE) 
            {
                //echo "<script>alert('Your record has been saved successfully');document.location='pay/paid.php'</script>";
				echo "<script>document.location='https://bitstutorconnect.co.ke'</script>";
            }
            else
            {
				echo "<script>document.location='https://bitstutorconnect.co.ke/learninganalysis.php?resVal='+$MarketerCode</script>";
            }


            ?>