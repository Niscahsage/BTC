<?php
session_start();
// this file recieves the posted values from signup.php, connects to the database and inserts the data into the table

//First allow all headers and cross origins
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Accesol-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Authorization');
$params = file_get_contents('php://input');

 $servername = "149.56.96.102";
$username = "bitstuto_zukbits";
$password = "5c{EBU!VoHUm";
$dbname = "bitstuto_schooldb";

	$conn = new mysqli($servername,$username,$password,$dbname);
    // declare variables to hold the posted values
    $email= $_REQUEST['email'];
    $message = $_REQUEST['message'];

   

    

    $sql = "INSERT INTO mail_tbl (Email_Address,Message) VALUES ('$email','$message' )";
    if($conn->query($sql) === TRUE){
        echo "Record was created successfully";
    }
    else{
        echo "Your data was not recorded. Please try again later!";
    }
?>

<?php
//$mess=  $_SESSION["massage"];

mail($email,'Mail Testing',$message);
?>




<!DOCTYPE html>
<html lang="en">
<body>
    

<form action="" method="post">
    <label for="email">Email Address:</label>
    <input type="emailaddress" id="email" name="email" required>
    <br>
    <label for="message">Message:</label>
    <textarea id="message" name="message" required></textarea>
    <br>
    <button type="submit">Submit</button>
</form>

</body>
</html>
