<?php
// This file receives the posted values from signup.php, connects to the database, and inserts the data into the table

// First allow all headers and cross origins
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Authorization');
$params = file_get_contents('php://input');

$servername = "localhost";//"149.56.96.102";
$username = "bitstuto";
$password = "w7Sj2nXb65J?";
$dbname = "bitstuto_schooldb";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Declare variables to hold the posted values
$email = $_REQUEST['email'];
$pdfFile = 'assets/images/btcleadgenerator.pdf'; // Ensure the file extension is correct
$mailMess = "Dear client,\n\nThank you for subscribing for Bits TuttorConnect newsletter!.\n\nBTC: Let's learn digitally!";

// Query to insert into the table
$sql = "INSERT INTO newsletter_tbl (email) VALUE ('$email')";
if ($conn->query($sql) === TRUE) {
    echo "<script>document.location='services.php'</script>";
} else {
    echo "Your data was not recorded. Please try again later!";
}

// Prepare the email headers and body with attachment
$boundary = md5(uniqid(time())); // Unique boundary for separating parts in the email

// Email headers
$headers = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";
$headers .= "From: bitstuto\r\n"; // Set your sender email

// Email body
$body = "--$boundary\r\n";
$body .= "Content-Type: text/plain; charset=ISO-8859-1\r\n";
$body .= "Content-Transfer-Encoding: base64\r\n\r\n";
$body .= chunk_split(base64_encode($mailMess));

// Attach PDF
if (file_exists($pdfFile)) {
    $pdfContent = file_get_contents($pdfFile);
    $pdfContent = chunk_split(base64_encode($pdfContent));
    $body .= "--$boundary\r\n";
    $body .= "Content-Type: application/pdf; name=\"" . basename($pdfFile) . "\"\r\n";
    $body .= "Content-Transfer-Encoding: base64\r\n";
    $body .= "Content-Disposition: attachment; filename=\"" . basename($pdfFile) . "\"\r\n\r\n";
    $body .= $pdfContent . "\r\n";
}

// End email
$body .= "--$boundary--";

// Send the email
mail($email, 'Newsletter', $body, $headers);

?>
