<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modal Search Popup</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <!-- Button to open the search modal -->
    <button id="openSearchModalBtn">Open Search</button>

    <!-- Search Modal -->
    <div id="searchModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Search</h2>
            <input type="text" id="searchInput" placeholder="Type to search...">
            <button id="searchBtn">Search</button>
        </div>
    </div>

    <!-- Result Modal -->
    <div id="resultModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Search Results</h2>
            <div id="searchResults"></div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
