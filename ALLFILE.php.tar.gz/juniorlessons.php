<?php

require 'dbconfig.php';

@$topSel=$_REQUEST['topic']; 
if(strlen($topSel) > 0 and !is_numeric($topSel)){ 
echo "Data Error";
exit;
}

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="icon" type="image/jpeg" href="assets/images/bos.png">

    <title>BTC: Let's learn digitally!</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-onix-digital.css">
    <link rel="stylesheet" href="assets/css/animated.css">
    <link rel="stylesheet" href="assets/css/owl.css">

<style>
.video {position: relative; width: 576px;}
.video iframe {display: block;}
.video .buttons {position: absolute; bottom: 0; z-index: 1; width: 100%; text-align: center; display: none;}
.video:hover .buttons {display: block;}
</style>
  </head>

<body>

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="index.php" class="logo">
              <img src="assets/images/bos.png">
            </a>

            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li class="scroll-to-section"><a href="/bitsonlineschool" class="active">Home</a></li>
              <li class="scroll-to-section"><a href="/bitsonlineschool">Services</a></li>
              <li class="scroll-to-section"><a href="/bitsonlineschool">About</a></li>
              <!--<li class="scroll-to-section"><a href="#portfolio">Resources</a></li>-->
              <li class="scroll-to-section"><a href="/bitsonlineschool">Sample Classes</a></li> 
            </ul>        
            <a class='menu-trigger'>
                <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->
  <div id="video" class="our-videos section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="naccs">
            <div class="grid">
              
              <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Classes</th>
                </tr>
              </thead>
              <tfoot>

                <tr>
                  <th>Classes</th>
                </tr>
              </tfoot>
                <?php
$servername = "149.56.96.102";
$username = "bitstuto_zukbits";
$password = "5c{EBU!VoHUm";
$dbname = "bitstuto_schooldb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

$sql = "SELECT a.id,a.resource,b.Name,b.Description from Lessons a INNER JOIN Topics b ON a.topic=b.id where topic='+$topSel+' order by id";
if (mysqli_query($conn, $sql)) {
echo "";
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
$count=1;
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
// output data of each row
while($row = mysqli_fetch_assoc($result)) { ?>
                        <tbody>
                           <tr>
                              <td>
                            <div class="video">
                                <iframe src= <?php echo $row['resource']; ?> autoplay="false" width="576" height="324" frameborder="0" disablecontrols allowfullscreen></iframe>
                                <div class="buttons" style="visibility: show">
                                <button type="button" style="width:576px; height: 324px" onclick="window.location = 'https://paydebttechsystems.co.ke/bitsonlineschool/juniorpay.php?resVal='+<?php echo $row['id']; ?>;" class="btn btn-primary">Please click to pay to access this lesson</button>
                                </div>
                            </div>
                              </td>
                        </tr>
                        </tbody>

                        <?php
$count++;
}
} else {
echo '0 results';
}
?>
              
            </table>
          </div>
        </div>
        
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="footer-dec">
    <img src="assets/images/footer-dec.png" alt="">
  </div>

footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <div class="about footer-item">
            <div class="logo">
              <a href="#"><img src="assets/images/btc.PNG" alt="Onix Digital TemplateMo"></a>
            </div>
            <a href="mailto:info@bitstutorconnect.co.ke">info@bitstutorconnect.co.ke</a>
            <ul>
              <li><a href="https://web.facebook.com/BitsOnlineSchool/" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <!--<li><a href="/bitsonlineschool"><i class="fa fa-twitter"></i></a></li>
              <li><a href="/bitsonlineschool"><i class="fa fa-youtube"></i></a></li>-->
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <!--<div class="services footer-item">
            <h4>Services</h4>
            <ul>
              <li><a href="elementaryclasses.php">Elementary School Content</a></li>
              <li><a href="advancedclasses.php">Advanced School Content</a></li>
            </ul>
          </div>-->
        </div>
        <div class="col-lg-3">
          <!--<div class="community footer-item">
            <h4>Community</h4>
            <ul>
              <li><a href="#">Schemes of Work</a></li>
              <li><a href="#">Q & A</a></li>
            </ul>
          </div>-->
        </div>
        <div class="col-lg-3">
          <!--<div class="subscribe-newsletters footer-item">
            <h4>Subscribe Newsletters</h4>
            <p>Get our latest news and ideas to your inbox</p>
            <form action="#" method="get">
              <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
              <button type="submit" id="form-submit" class="main-button "><i class="fa fa-paper-plane-o"></i></button>
            </form>
          </div>-->
        </div>
        <div class="col-lg-12">
          <div class="copyright">
            <p>Copyright © <?php echo date('Y');?> Bits TutorConnect. All Rights Reserved. 
            <br></p>
          </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Scripts -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/animation.js"></script>
  <script src="assets/js/imagesloaded.js"></script>
  <script src="assets/js/custom.js"></script>

  <script>
  // Acc
    $(document).on("click", ".naccs .menu div", function() {
      var numberIndex = $(this).index();

      if (!$(this).is("active")) {
          $(".naccs .menu div").removeClass("active");
          $(".naccs ul li").removeClass("active");

          $(this).addClass("active");
          $(".naccs ul").find("li:eq(" + numberIndex + ")").addClass("active");

          var listItemHeight = $(".naccs ul")
            .find("li:eq(" + numberIndex + ")")
            .innerHeight();
          $(".naccs ul").height(listItemHeight + "px");
        }
    });
  </script>
</body>
</html>