Instructions:
1) Stop the application if started
2) Install application using provided installer and do not reboot
3) Run patch file
DONE!
 

www.Techtools.net /  www.ThumperDC.com