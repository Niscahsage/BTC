<?php

require 'dbconfig.php';
//////// End of connecting to database ////////

@$cat=$_GET['cat']; // Use this line or below line if register_global is off
if(strlen($cat) > 0 and !is_numeric($cat)){ // to check if $cat is numeric data or not. 
echo "Data Error";
exit;
}
@$subcat=$_GET['subcat']; // Use this line or below line if register_global is off
if(strlen($subcat) > 0 and !is_numeric($subcat)){ // to check if $cat is numeric data or not. 
echo "Data Error";
exit;
}
//@$cat=$HTTP_GET_VARS['cat']; // Use this line or above line if register_global is off
/*
If register_global is off in your server then after reloading of the page to get the value of cat from query string we have to take special care.
To read more on register_global visit.
  http://www.plus2net.com/php_tutorial/register-globals.php
*/

?>

<!doctype html public "-//w3c//dtd html 3.2//en">

<html>

<head>
<title>Multiple drop down list box from plus2net</title>
<SCRIPT language=JavaScript>
<!--
function reload(form)
{
var val=form.cat.options[form.cat.options.selectedIndex].value;
var vl=form.subcat.options[form.subcat.options.selectedIndex].value;
self.location='slect.php?cat=' + val+'&subcat=' + vl;
}
//-->

</script>
</head>

<body >

<?Php

///////// Getting the data from Mysql table for first list box//////////
$query2="SELECT DISTINCT id,Name FROM Categories order by Name"; 
///////////// End of query for first list box////////////


echo "<form method=post name=f1 action='dd-check.php'>";
//////////        Starting of first drop downlist /////////
echo "<select name='cat' onchange=\"reload(this.form)\"><option value=''>Select Category</option>";
if($stmt = $conn->query("$query2")){
	while ($row2 = $stmt->fetch_assoc()) {
	if($row2['id']==@$cat){echo "<option selected value='$row2[id]'>$row2[Name]</option>";}
else{echo  "<option value='$row2[id]'>$row2[Name]</option>";}

  }
}else{
echo $conn->error;
}

echo "</select>";
//////////////////  This will end the first drop down list ///////////
echo "<select name='subcat' onchange=\"reload(this.form)\"><option value=''>Select Class</option>";
if(isset($cat) and strlen($cat) > 0){
if($stmt = $connection->prepare("SELECT DISTINCT id,Name FROM Classes where Category=? order by Name")){
$stmt->bind_param('i',$cat);
$stmt->execute();
 $result = $stmt->get_result();
 while ($row1 = $result->fetch_assoc()) {
     	if($row1['id']==@$subcat){echo "<option selected value='$row1[id]'>$row1[Name]</option>";}
else{echo  "<option value='$row1[id]'>$row1[Name]</option>";}
  //echo  "<option value='$row1[id]'>$row1[Name]</option>";
	}

}else{
 echo $conn->error;
} 

/////////
}
else{

echo $conn->error;


} 
////////// end of query for second subcategory drop down list box ///////////////////////////
echo "</select>";
//////////////////  This will end the second drop down list ///////////

echo "<select name='topic'><option value=''>Select one</option>";
if(isset($subcat) and strlen($subcat) > 0){
if($stm = $conn->prepare("SELECT DISTINCT id,Name FROM Topics where Class=?  order by Name")){
$stm->bind_param('i',$subcat);
$stm->execute();
 $result = $stm->get_result();
 while ($row1 = $result->fetch_assoc()) {
  echo  "<option value='$row1[id]'>$row1[Name]</option>";
	}

}else{
 echo $conn->error;
} 

/////////
}
else{
echo $conn->error;
} 
 ///////////////////////////
echo "</select>";
//////////////////  This will end the third drop down list ///////////

echo "<input type=submit value='Submit'></form>";

?>
<br><br>
<a href=dd-mysqli.php>Reset and start again</a>
<br><br>
<center><a href='http://www.plus2net.com' rel="nofollow">PHP SQL HTML free tutorials and scripts</a></center> 
</body>

</html>
