<?php
require 'dbconfig.php';
//$phone = '';
//@$phone=$_GET['phone'];
$phone =$_REQUEST['phone'];
//if(!strlen($phone) < 0 and !is_numeric($phone)){
//echo "Data Error";
//exit;
//}
//else
//{
	if(mb_substr($phone, 0, 3)!= 254)
       {
           $phone = '254'.($phone * 1);
		//echo "<script>document.location='advanced.php'</script>";
       }
       else
       {
          $phone =  $phone;

       }
	//echo "<script>document.location='subscription.php&phone='+$phone</script>";
	//echo $phone;
//}

//self.location='advanced.php?phone=' + pvl;


@$cat=$_GET['cat']; // Use this line or below line if register_global is off
if(strlen($cat) > 0 and !is_numeric($cat)){ // to check if $cat is numeric data or not. 
echo "Data Error";
exit;
}

@$subcat=$_GET['subcat']; 
if(strlen($subcat) > 0 and !is_numeric($subcat)){ 
echo "Data Error";
exit;
}

@$topic=$_GET['topic']; 
if(strlen($topic) > 0 and !is_numeric($topic)){  
echo "Data Error";
exit;
}
    $username = "";//"https://muse.ai/embed/z8T687j?search=0&links=0&logo=0";

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="icon" type="image/jpeg" href="assets/images/bos.jpg">

    <title>BTC: Let's learn digitally!</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-onix-digital.css">
    <link rel="stylesheet" href="assets/css/animated.css">
    <link rel="stylesheet" href="assets/css/owl.css">
<!--

TemplateMo 565 Onix Digital

https://templatemo.com/tm-565-onix-digital

-->
<style>
.video {position: relative; width: 576px;}
.video iframe {display: block;}
.video .buttons {position: absolute; bottom: 0; z-index: 1; width: 100%; text-align: center; display: none;}
.video:hover .buttons {display: block;}
</style>
  </head>

<body>


  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <!--<a href="index.php" class="logo">
              <img src="assets/images/bos.png">
            </a>-->

            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li class="scroll-to-section"><a href="/bitsonlineschool" class="active">Home</a></li>
              <li class="scroll-to-section"><a href="/bitsonlineschool/advanced.php">Start Watching</a></li>
              <li class="scroll-to-section"><a href="/bitsonlineschoolt/index.php#about">About</a></li> 
            </ul>        
            <a class='menu-trigger'>
                <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->
  <div id="video" class="our-videos section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="naccs">
            <div class="grid">
              <div class="row">
                  <div style="height:10px">
                      
                  </div>
				  <div class="row">
					  <form method="post" name="form-search" action="advanced.php">
                      <input class="col-lg-2" type="number" name="phone" id="phone" placeholder="Your Phone" required />
					  <input type=submit id="form-search" value="Search">
					  </form>
                  </div>
                <!--<div class="video">
                    <iframe src="<?php echo $username; ?>" width="576" height="324" frameborder="0" disablecontrols allowfullscreen></iframe>
                         <div class="buttons">
                            <button type="button" style="width:576px; height: 324px" onclick="muteUnmute(this)" class="btn btn-primary">Please Subscribe First</button>
                        </div>
                </div>-->
				  
				  <!--Lesson Display Start-->
				  <!--Lesson Display End-->
				  <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <!--<th>Lessons</th>-->
					<th>Lesson Description</th>
                </tr>
              </thead>
              <tfoot>

                <tr>
                  <th>Lesson Description</th>
                </tr>
              </tfoot>
                <?php
					$num = "254721850599";
					$servername = "localhost";//"149.56.96.102";
					$username = "bitstuto";
					$password = "w7Sj2nXb65J?";
					$dbname = "bitstuto_schooldb";

					// Create connection
					$conn = new mysqli($servername, $username, $password, $dbname);

$sql = "SELECT bitschoolpay.PhoneNumber,bitschoolpay.resource AS resID,bitschoolpay.status,Lessons.resource FROM bitschoolpay INNER JOIN Lessons ON bitschoolpay.resource=Lessons.id WHERE bitschoolpay.PhoneNumber='$phone' AND bitschoolpay.status='hidden'";
if (mysqli_query($conn, $sql)) {
echo "";
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
$count=1;
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
// output data of each row
while($row = mysqli_fetch_assoc($result)) { ?>
                        <tbody>
                           <tr>
                              <td>
                            <div class="video">
                                <iframe src= <?php echo $row['resource']; ?> autoplay="false" width="576" height="324" frameborder="0" disablecontrols allowfullscreen></iframe>
                                
                            </div>
                              </td>
                        </tr>
                        </tbody>

                        <?php
$count++;
}
} else {
echo 'You do not have any lesson pending to be watched. Please purchase one from our various categories';
}
?>
              
            </table>
          </div>
        </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="footer-dec">
    <img src="assets/images/footer-dec.png" alt="">
  </div>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <div class="about footer-item">
            <div class="logo">
              <a href="#"><img src="assets/images/bos.png" alt="Onix Digital TemplateMo"></a>
            </div>
            <a href="mailto:info@zukbitsonline.co.ke">info@zukbitsonline.co.ke</a>
            <ul>
              <li><a href="/bitsonlineschool"><i class="fa fa-facebook"></i></a></li>
              <li><a href="/bitsonlineschool"><i class="fa fa-twitter"></i></a></li>
              <li><a href="/bitsonlineschool"><i class="fa fa-youtube"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="services footer-item">
            <h4>Services</h4>
            <ul>
              <li><a href="/bitsonlineschool/elementaryclasses.php">Basic Learning Content</a></li>
              <li><a href="/bitsonlineschool/advancedclasses.php">Advanced Learning Content</a></li>
				<li><a href="/bitsonlineschool/juniorclasses.php">JSS Learning Content</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="community footer-item">
            <h4>Community</h4>
            <ul>
              <li><a href="/bitsonlineschool">More Resources</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="subscribe-newsletters footer-item">
            <h4>Subscribe Newsletters</h4>
            <p>Get our latest news and ideas to your inbox</p>
            <form action="/bitsonlineschool" method="get">
              <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
              <button type="submit" id="form-submit" class="main-button "><i class="fa fa-paper-plane-o"></i></button>
            </form>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="copyright">
            <p>Copyright © <?php echo date('Y');?> Bits Tutor Connect. All Rights Reserved. 
            <br></p>
          </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Scripts -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/animation.js"></script>
  <script src="assets/js/imagesloaded.js"></script>
  <script src="assets/js/custom.js"></script>

  <script>
  // Acc
    $(document).on("click", ".naccs .menu div", function() {
      var numberIndex = $(this).index();

      if (!$(this).is("active")) {
          $(".naccs .menu div").removeClass("active");
          $(".naccs ul li").removeClass("active");

          $(this).addClass("active");
          $(".naccs ul").find("li:eq(" + numberIndex + ")").addClass("active");

          var listItemHeight = $(".naccs ul")
            .find("li:eq(" + numberIndex + ")")
            .innerHeight();
          $(".naccs ul").height(listItemHeight + "px");
        }
    });
  </script>
<script language=JavaScript>
<!--
function reload(form)
{
    var pvl = document.getElementById('phone').value; //form.phone.options[form.phone.options.selectedIndex].value;
    //var val=form.cat.options[form.cat.options.selectedIndex].value;
    //var Tpval=form.topic.options[form.topic.options.selectedIndex].value;
    //var vl=form.subcat.options[form.subcat.options.selectedIndex].value;
//self.location='advanced.php?cat=' + val+'&subcat=' + vl + '&topic=' + Tpval + '&phone=' + pvl;
	self.location='advanced.php?phone=' + pvl;
}
//-->

</script>
</body>
</html>