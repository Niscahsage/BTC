<?php
mail('dngwono@gmail.com', 'Mpesa Payment Confirmation', 'Test Mail for now');
?>