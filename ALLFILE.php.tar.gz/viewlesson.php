<?php
  session_start();
  
    include_once('dbconfig.php');

/*$phone =$_REQUEST['phone'];
//if(!strlen($phone) < 0 and !is_numeric($phone)){
//echo "Data Error";
//exit;
//}
//else
//{
	if(mb_substr($phone, 0, 3)!= 254)
       {
           $phone = '254'.($phone * 1);
		//echo "<script>document.location='advanced.php'</script>";
       }
       else
       {
          $phone =  $phone;

       }
*/

  if (isset($_POST['submit'])) {
      
  $errorMsg = "";
      //$phone = $conn->real_escape_string($_POST['phone']);
      $phone =$_POST['phone'];
      
      	if(mb_substr($phone, 0, 3)!= 254)
       {
           $phone = '254'.($phone * 1);
		//echo "<script>document.location='advanced.php'</script>";
       }
       else
       {
          $phone =  $phone;

       }
      
  if (!empty($phone)) {
        $query = "SELECT bitschoolpay.PhoneNumber,bitschoolpay.resource AS resID,bitschoolpay.status,Lessons.resource FROM bitschoolpay INNER JOIN Lessons ON bitschoolpay.resource=Lessons.id WHERE bitschoolpay.PhoneNumber='$phone' AND bitschoolpay.status='hidden' ORDER BY bitschoolpay.id DESC Limit 1";
        $result = $conn->query($query);
        if($result->num_rows > 0){
            $row = $result->fetch_assoc();
            //$_SESSION['ID'] = $row['id'];
            $_SESSION['phone'] = $row['PhoneNumber'];
            $_SESSION['resourceloc'] = $row['resource'];
            header("Location:mylesson.php");
            die();                              
        }else{
          $errorMsg = "There are no lessons pending to be viewed";
        } 
    }else{
      $errorMsg = "Phone Number is required";
    }
  }

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="icon" type="image/jpeg" href="assets/images/btc.PNG">

    <title>BTC: Let's learn digitally!</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-onix-digital.css">
    <link rel="stylesheet" href="assets/css/animated.css">
    <link rel="stylesheet" href="assets/css/owl.css">
<!--

TemplateMo 565 Onix Digital

https://templatemo.com/tm-565-onix-digital

-->
<style>
.video {position: relative; width: 576px;}
.video iframe {display: block;}
.video .buttons {position: absolute; bottom: 0; z-index: 1; width: 100%; text-align: center; display: none;}
.video:hover .buttons {display: block;}
</style>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script>
    setTimeout(function() {
    document.getElementById("#myModal");
    $("#myModal").modal('show');
	},3000); // 3 second delay in ms.
</script>
<script>
function myFunction() {
  document.getElementById("#myModal");
   $("#myModal").modal('hide');
}
</script>
  </head>

<body>
<!--Modal popup-->
<div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content" style="margin-top: 50%; margin-right: 50%">
            <div class="modal-header">
                <button type="button" OnClick="myFunction()" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-header" style="text-align: center">
                <h5 class="col-lg-12">Lesson Viewing Alert!</h5>
            </div>
            <div class="col-lg-12">
                <br/>
                    <div class="col-lg-12" style="text-align: center; background-color: red">
                     <p style="color:white">This page allows you to revisit lessons purchased not more than 90 minutes ago.</p>
                    </div>
                    <hr/>
                    <div class="col-lg-12" style="text-align: center; background-color:green; ">
                        <p style="color:white;">Enter the phone number you used to pay for the lesson and click on Load Lesson button to start viewing your purchased lesson</p><br/>
                    </div><br/>
            </div>
        </div>
    </div>
</div>
<!--end of modal popup-->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="index.php" class="logo">
              <img src="assets/images/btc.PNG">
            </a>

            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li class="scroll-to-section"><a href="index.php" class="active">Home</a></li>
              <li class="scroll-to-section"><a href="viewlesson.php">Start Watching</a></li>
              <li class="scroll-to-section"><a href="about.php">About</a></li> 
            </ul>        
            <a class='menu-trigger'>
                <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->
  <div id="video" class="our-videos section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="naccs">
            <div class="grid">
              <div class="row">
                  <div style="height:10px">
                      
                  </div>
				  <div class="row">
					  <p style="color:red">Please enter the phone number you used to pay for the lesson and click Load lesson button</p>
					  <form method="POST" name="form-search" action="">
                      <input class="col-lg-3" type="text" maxlength="15" name="phone" id="phone" placeholder="Phone Number e.g 0721****99" required />
					  <!--<Button type=submit id="form-search" value="Load Lesson"></Button>-->
					  <Button type="submit" name="submit" id="submit" >Load Lesson</Button>
					  </form>
                  </div>
                <!--<div class="video">
                    <iframe src="<?php echo $username; ?>" width="576" height="324" frameborder="0" disablecontrols allowfullscreen></iframe>
                         <div class="buttons">
                            <button type="button" style="width:576px; height: 324px" onclick="muteUnmute(this)" class="btn btn-primary">Please Subscribe First</button>
                        </div>
                </div>-->
				  
				  <!--Lesson Display Start-->
				  <!--Lesson Display End-->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="footer-dec">
    <img src="assets/images/footer-dec.png" alt="">
  </div>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <div class="about footer-item">
            <div class="logo">
              <a href="#"><img src="assets/images/btc.PNG" alt="Onix Digital TemplateMo"></a>
            </div>
            <a href="mailto:info@bitstutorconnect.co.ke">info@bitstutorconnect.co.ke</a>
            <ul>
              <li><a href="https://web.facebook.com/BitsOnlineSchool/" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <!--<li><a href="/bitsonlineschool"><i class="fa fa-twitter"></i></a></li>
              <li><a href="/bitsonlineschool"><i class="fa fa-youtube"></i></a></li>-->
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <!--<div class="services footer-item">
            <h4>Services</h4>
            <ul>
              <li><a href="elementaryclasses.php">Elementary School Content</a></li>
              <li><a href="advancedclasses.php">Advanced School Content</a></li>
            </ul>
          </div>-->
        </div>
        <div class="col-lg-3">
          <!--<div class="community footer-item">
            <h4>Community</h4>
            <ul>
              <li><a href="#">Schemes of Work</a></li>
              <li><a href="#">Q & A</a></li>
            </ul>
          </div>-->
        </div>
        <div class="col-lg-3">
          <!--<div class="subscribe-newsletters footer-item">
            <h4>Subscribe Newsletters</h4>
            <p>Get our latest news and ideas to your inbox</p>
            <form action="#" method="get">
              <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
              <button type="submit" id="form-submit" class="main-button "><i class="fa fa-paper-plane-o"></i></button>
            </form>
          </div>-->
        </div>
        <div class="col-lg-12">
          <div class="copyright">
            <p>Copyright © <?php echo date('Y');?> Bits TutorConnect. All Rights Reserved. 
            <br></p>
          </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Scripts -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/animation.js"></script>
  <script src="assets/js/imagesloaded.js"></script>
  <script src="assets/js/custom.js"></script>

  <script>
  // Acc
    $(document).on("click", ".naccs .menu div", function() {
      var numberIndex = $(this).index();

      if (!$(this).is("active")) {
          $(".naccs .menu div").removeClass("active");
          $(".naccs ul li").removeClass("active");

          $(this).addClass("active");
          $(".naccs ul").find("li:eq(" + numberIndex + ")").addClass("active");

          var listItemHeight = $(".naccs ul")
            .find("li:eq(" + numberIndex + ")")
            .innerHeight();
          $(".naccs ul").height(listItemHeight + "px");
        }
    });
  </script>
<script language=JavaScript>
<!--
function reload(form)
{
    var pvl = document.getElementById('phone').value; //form.phone.options[form.phone.options.selectedIndex].value;
    //var val=form.cat.options[form.cat.options.selectedIndex].value;
    //var Tpval=form.topic.options[form.topic.options.selectedIndex].value;
    //var vl=form.subcat.options[form.subcat.options.selectedIndex].value;
//self.location='advanced.php?cat=' + val+'&subcat=' + vl + '&topic=' + Tpval + '&phone=' + pvl;
	self.location='viewlesson.php?phone=' + pvl;
}
//-->

</script>
</body>
</html>