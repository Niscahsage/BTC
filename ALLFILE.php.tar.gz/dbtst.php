<?php
$host = 'localhost';//'149.56.96.102';
$dbname = 'bitstuto_schooldb';
$username = 'bitstuto';
$password = 'w7Sj2nXb65J?';

// Create a MySQLi connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Connected successfully!";
?>
