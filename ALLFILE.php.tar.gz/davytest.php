<?php
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" 
          content="width=device-width, 
                   initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      href=
"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity=
"sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link rel="stylesheet"
          href="stylo.css" />
    <link rel="preconnect" 
          href="https://fonts.gstatic.com" />
    <link
      href=
"https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap"
      rel="stylesheet"
    />
    <link rel="icon" type="image/jpeg" href="assets/images/btc.PNG">
    <title>BTC: Let's learn digitally!</title>
  </head>
  <body>
    <section id="navbar">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
             <img src="assets/images/btc.PNG">
            </a>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" 
               id="navbarSupportedContent">
            <ul class="navbar-nav m-auto">
              <li class="nav-item">
                <a class="nav-link active" 
                   aria-current="page" 
                   href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" 
                   href="services.php">Services</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" 
                   href="about.php">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" 
                   href="product.php">Products</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" 
                   href="social.php">Contact Us</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </section>

    <!-- banner -->
    <section id="banner">
      <div class="container-fluid" id="banner-container">
        <div class="row" id="banner-row">
          <div class="col-md-6" id="banner-col">
            <!--<p style="background-color:#1C0708; font-size:18px; margin-top:-30px; text-align:center;">
                Vision : To be the learner's most trusted guide towards academic excellence!</p><br/>
                <p style="background-color:white;color:black; font-size:18px; margin-top:-40px; text-align:center;"></p><br/>
                <p style="background-color:#8D272B; font-size:18px; margin-top:-40px;">
                 Mission : We exist to help remove all barriers to quality grades for the learner and their schools by offering a digital solution to their financial and staffing struggles at academics.</p><br/>
                <p style="background-color:white;color:black; font-size:18px; margin-top:-40px; text-align:center;"></p><br/>
                <p style="background-color:green; font-size:18px; margin-top:-40px;">
                Core Values : Quality, Affordability, Digitization</p><br/>-->
                <p style="font-size:20px;">
                The benefits we bring to our client as a learner, parent or teacher are immense:<br/>
            &#8211; Content access at rock-bottom rates 
            &#8211; Quick access to classroom lessons 
            &#8211; most optimal utilization of the phone by our learners
            &#8211; Encounters with the most professional tutors 
            &#8211; Avoidance of risks associated with commuting for tutorials 
            &#8211; No time wasted commuting for tutorials 
            &#8211; Tutors can equally earn from the platform 
            &#8211; At last a teacher has appeared for the homeschoolers
                  </p>

            <div class="d-grid gap-2 d-md-flex justify-content-center" style="margin-top:-30px;">
              <a class="btn btn-primary" 
                 href="#" 
                 role="button">Contact Us</a>
            </div>
          </div>
          <div class="col-md-6" id="banner-col2" style="margin-top:-10px;">
            <img
              class="img-responsive rounded mx-auto d-block"
              src="assets/images/fall.jpg"
              alt="" style="width:950px;height:750px;" />
          </div>
        </div>
      </div>
    </section>

    <!-- services -->
    <section id="service">
      <h1 class="text-center">SERVICES</h1>
      <div class="container-fluid" id="service-container" style="margin-top:-40px;">
        <div class="row" id="banner-row">
          <div class="col-md-4" id="service-col1" style="background-color:#a15501; font-size:20px;color:white;">
            <img
              src="assets/images/morningrush.jpg"
              class="img-fluid rounded mx-auto d-block"
              alt="..." style="width:300px; height:300px;"
            />
            <h3>Elementary Learning</h3>
            <p >
                  Learner access to Basic learning is such a basic need for every child. We however reckon that such access has remained rather elusive to many falling in this bracket.<br/>Some of the most prevalent challenges have been:<br/> &#8211;distances traveled to school,<br/> 
                  &#8211;understaffing in institutions of learning,<br/> &#8211;poverty,<br/> &#8211;hunger, <br/>&#8211;sickness, among others.<br/>
                With these considerations, BTC has provided a portal allowing for every child to access their lessons most conveniently. Below are the subjects BTC has profiled lessons for the elementary learner: Maths, English, Kiswahili, Science, Art and Music at only 40/- per lesson.
                  </p>
                  
                  <div class="d-grid gap-2 d-md-flex justify-content-center" style="margin-top:-30px;">
              <a class="btn btn-primary" 
                 href="#" 
                 role="button">Go to Class</a>
            </div>

          </div>
          <div class="col-md-4" id="service-col2" style="background-color:#aa9977; font-size:20px;color:white;">
            <img
              src="assets/images/hallway.jpg"
              class="img-fluid rounded mx-auto d-block"
              alt="..." style="width:300px; height:300px;"
            />
            <h3>JSS Learning</h3>
            <p>
                   The CBC is a new curriculum largely hinged on competence development and relevance to real-life situations. Reality is; the new curriculum has been received with excitement and panic in equal measure.
Scarcity of tutors and necessary resources notwithstanding, BTC presents you with your most needed bailout in all key CBC learning areas. At our virtual platform (BTC), we offer you up-to-speed tutorial lessons specially presented by our CBC champions most conveniently -digitally!
In the meantime, we are offering tutorials in seven Learning Areas, viz: Mathematics, Integrated Science; Health Educ, Agriculture, Life Skills, Sports & Physical Educ and Home Science.
Kindly click on the on the link below to go to class right away.
                  </p>
                  <div class="d-grid gap-2 d-md-flex justify-content-center" style="margin-top:-30px;">
              <a class="btn btn-primary" 
                 href="#" 
                 role="button">Go to Class</a>
            </div>

          </div>
          <div class="col-md-4" id="service-col3" style="background-color:#546a6e; font-size:20px;color:white;">
            <img
              src="assets/images/advanced.jpg"
              class="img-fluid rounded mx-auto d-block"
              alt="..." style="width:300px; height:300px;"
            />
            <h3>Advanced Learning</h3>
            <p>
                   Essentially, post elementary learning is what defines the future prospects of the learner. It is no doubt the most crucial stage of ones life.<br/>While the workload at this level can at times be one overbearing, learners often encounter challenges beyond their capabilities. Out of this reality, these learners require an available and versatile support system that will empower them to surmount their performance challenges relating, but not limited to; absenteeism owing to fee challenges, challenging subjects/topics, workload, attitude against teachers, negative effects of the phone/TV, etc.<br/>To mitigate against such drawbacks, BTC has availed makeup lessons in the following learning areas: Math, English Literature, Swahili Fasihi, Biology, Chemistry, Physics at only 50/- per one hour lesson.
                  </p>
                  <div class="d-grid gap-2 d-md-flex justify-content-center" style="margin-top:-32px;">
              <a class="btn btn-primary" 
                 href="#" 
                 role="button">Go to Class</a>
            </div>

          </div>
        </div>
      </div>
    </section>
    <hr />

    <!-- about Us -->
    <section id="about" style="margin-top:-50px; background-color:#a69eb0; color:white;font-size:20px;">
      <h1 class="text-center">About Us</h1>
      <div class="container-fluid" id="about-container">
        <div class="row" id="banner-row">
          <div class="col-md-6" id="about-col">
              <p>
                 BTC is a virtual school for all levels of basic education on Kenya's curriculum. Having studied performance challenges facing learners n schools owing to fee challenges, understaffing, absence from school, we chose to be a partner in bridging the gap digitally. Our promise is to help learners and schools turn around their academic by having the learners access lessons affordably wherever they are irrespective of their financial circumstances. Ours is a tale of availing a teacher to every learner at the click of a button on the phone, computer, tablet or smart TV. Our commitment to quality, immediacy and convenience drives all our engagements with you as our client. Simply, when times are hard, internet so rampant and quality grades your top priority we check in as your trusted partner! 
              </p>

          </div>
          <div class="col-md-6" id="banner-col2">
            <img
              src="assets/images/interact.jpg"
              class="img-fluid rounded mx-auto d-block"
              alt="..."
            />
          </div>
        </div>
      </div>
    </section>
    <hr />
    <!-- product -->

    <section id="product" style="margin-top:-40px;">
      <h1 class="text-center">Our Packages</h1>
      <div class="container-fluid" id="product-container">
        <div class="row" id="banner-row">
          <div class="col-md-6" id="about-col">
            <img
              src="assets/images/interact.jpg"
              class="img-fluid rounded mx-auto d-block"
              alt="..."
            />
          </div>
          <div class="col-md-6" id="product-col2">
            <h3>Package List</h3>

            <ul>
              <li>ECDE Learning</li>
              <li>Elementary Learning</li>
              <li>JSS Learning</li>
              <li>Advanced Learning</li>
              <li>Home Schooling</li>
              <li>School Packages</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <hr />
    <!-- social -->
    <section id="social" style="margin-top:-40px;">
      <h1 class="text-center">Get In Touch</h1>
      <div class="d-grid gap-2 d-md-flex justify-content-center">
        <div class="row align-items-center" id="social-row">
          <div class="col-md-4 social-col">
            <a href=""
              ><img
                class="img-responsive rounded mx-auto d-block"
                src="images/gfg.png"
                alt=""
            /></a>
          </div>
          <div class="col-md-4 social-col">
            <a href=""
              ><img
                class="img-responsive rounded mx-auto d-block"
                src="images/icons8-instagram-64.png"
                alt=""
            /></a>
          </div>
          <div class="col-md-4 social-col">
            <a href=""
              ><img
                class="img-responsive rounded mx-auto d-block"
                src="images/icons8-twitter-64.png"
                alt=""
            /></a>
          </div>
        </div>
      </div>
    </section>

    <!-- footer -->
    <section id="footer">
      <section id="banner">
        <div class="container-fluid" id="banner-container">
          <div class="row" id="banner-row">
            <div class="col-md-4" id="footer-col1">
              <h3>BTC</h3>
              
<p>
                Let your child realize educational value for their time spent online.
              </p>

            </div>
            <div class="col-md-4" id="footer-col2">
              <h3>Contact Us</h3>
              
<p>Call Us- +254 (0) 722310358</p>

              
<p>Email Us- info@bitstutorconnect.co.ke</p>
<p> Write Us- P.O Box 955-90200, 
Kitui</p>

            </div>

            <div class="col-md-4" id="footer-col2">
              <h3>Subscribe To Newsletter</h3>
              <form>
                <div class="mb-3">
                  <input
                    type="email"
                    placeholder="Enter Your Email"
                    class="form-control"
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                  />
                  <div id="emailHelp" 
                       class="form-text">
                    We'll never share your email with anyone else.
                  </div>
                </div>
                <button type="submit" 
                        class="btn btn-primary">
                        Submit
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </section>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script
      src=
"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
      integrity=
"sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
