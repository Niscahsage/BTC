<?php
echo phpinfo();
?>