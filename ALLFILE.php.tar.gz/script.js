// Get modal elements
const searchModal = document.getElementById("searchModal");
const resultModal = document.getElementById("resultModal");

// Get buttons
const openSearchModalBtn = document.getElementById("openSearchModalBtn");
const searchBtn = document.getElementById("searchBtn");

// Get close elements
const closeElements = document.getElementsByClassName("close");

// Display the search modal
openSearchModalBtn.onclick = function() {
    searchModal.style.display = "block";
}

// Close the modals when the close button is clicked
for (let i = 0; i < closeElements.length; i++) {
    closeElements[i].onclick = function() {
        searchModal.style.display = "none";
        resultModal.style.display = "none";
    }
}

// Perform a search and show the results in the result modal
searchBtn.onclick = function() {
    const searchValue = document.getElementById("searchInput").value;

    // Dummy search result for demonstration purposes
    const resultText = "Results for: " + searchValue;

    // Show the result modal and set the result content
    document.getElementById("searchResults").innerText = resultText;
    searchModal.style.display = "none"; // Close the search modal
    resultModal.style.display = "block"; // Show the result modal
}

// Close modals when clicking outside of them
window.onclick = function(event) {
    if (event.target == searchModal) {
        searchModal.style.display = "none";
    }
    if (event.target == resultModal) {
        resultModal.style.display = "none";
    }
}
