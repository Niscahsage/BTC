<?php
echo "We are coming to your devices with goodies soon!";
?>