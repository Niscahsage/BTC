<?php
 header('Access-Control-Allow-Origin: *'); 
    header("Access-Control-Allow-Credentials: true");
    header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');//  
    header('Access-Control-Max-Age: 1000');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
   $params = file_get_contents('php://input');
   
    
    require_once('bitschMpesa.php');
    $mpesa = (new BitMpesa())->initiateStk();
    $pamData = json_decode($mpesa,true);
   
   $ResValue = $_REQUEST['resVal'];
   
   echo $ResValue;
    
    //echo "<script>document.location='paid.php'</script>";
    
               //Connect to MSSQL
       $servername = "localhost";//"149.56.96.102";
$username = "bitstuto";
$password = "w7Sj2nXb65J?";
$dbname = "bitstuto_schooldb";

       $phoneNumber =$_REQUEST['phone_number'];
       if(mb_substr($phoneNumber, 0, 3)!= 254)
       {
           $PhoneNumber = '254'.($phoneNumber * 1); 
       }
       else
       {
          $PhoneNumber =  $phoneNumber;
       }
       
       $Amount = 2;
       
       $category = $_REQUEST['subcat'];
       if($category == "Elementary Annual Subscription")
       {
           $Category = 1;
       }
       else
       {
           $Category = 2;
       }
       $Name = $_REQUEST['name'];
       $TransactionDesc = $_REQUEST['phone_number'];
       $TransactionDate='';
       $RequestDate = '';
       $StartDate = '';
       $EndDate = '';
       $MerchantRequestID = $pamData['MerchantRequestID'];
       $CheckoutRequestID = $pamData['CheckoutRequestID'];
       $MpesaReceiptNumber = '';
       $ResultCode = $pamData['ResultCode'];
       $Processed = '0';
       $ResultDesc = $pamData['ResultDesc'];
       
       // Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);

        $sql = "INSERT INTO bitschoolpay (PhoneNumber,Name,StartDate,EndDate,Amount,Category,MerchantRequestID,CheckoutRequestID,ResultCode,ResultDesc,MpesaReceiptNumber,TransactionDate,TransactionDesc,RequestDate,Processed) VALUES ('$PhoneNumber','$Name','$StartDate','$EndDate','$Amount','$Category','$MerchantRequestID','$CheckoutRequestID','$ResultCode','$ResultDesc','$MpesaReceiptNumber','$TransactionDate','$TransactionDesc','$RequestDate','$Processed')";
        
            if ($conn->query($sql) === TRUE) 
            {
                
            }
            else
            {
                echo "Failed to create Record";
            }
            ?>