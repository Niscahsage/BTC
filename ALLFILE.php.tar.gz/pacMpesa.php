<?php
class PacMpesa{

    public function initiateStk()
    {
                       //Connect to MSSQL
       $servername = "localhost";//"149.56.96.102";
$username = "bitstuto";
$password = "w7Sj2nXb65J?";
$dbname = "bitstuto_schooldb";

       $passKey = '656c110446b951a8f402ec4988ec8c58b05c5014eabd38a8e5b37273f139874a';  
        $ar ='"';
       $PhoneNumber = $_REQUEST['phone_number'];
       if(mb_substr($PhoneNumber, 0, 3)!= 254)
       {
           $PhoneNumber = '254'.($PhoneNumber * 1); 
       } 
       $category = $_REQUEST['cat'];
       if($category == "Standard")
       {
           		// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
    	$sqlqry = "SELECT amount FROM charges WHERE id=12";
  		$sendDtls = $conn->query($sqlqry);
  		$data_array = $sendDtls->fetch_assoc();
           $Amount = $data_array['amount'];
           $Category = 1;
       }
		else if($category == "Silver")
       {
           		// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
    	$sqlqry = "SELECT amount FROM charges WHERE id=13";
  		$sendDtls = $conn->query($sqlqry);
  		$data_array = $sendDtls->fetch_assoc();
           $Amount = $data_array['amount'];
           $Category = 2;
       }
       else if($category == "BtcLite")
       {
           		// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
    	$sqlqry = "SELECT amount FROM charges WHERE id=16";
  		$sendDtls = $conn->query($sqlqry);
  		$data_array = $sendDtls->fetch_assoc();
           $Amount = $data_array['amount'];
           $Category = 7;
       }
       else if($category == "Bronze")
       {
           		// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
    	$sqlqry = "SELECT amount FROM charges WHERE id=17";
  		$sendDtls = $conn->query($sqlqry);
  		$data_array = $sendDtls->fetch_assoc();
           $Amount = $data_array['amount'];
           $Category = 8;
       }
       else
       {
		              		// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
    	$sqlqry = "SELECT amount FROM charges WHERE id=14";
  		$sendDtls = $conn->query($sqlqry);
  		$data_array = $sendDtls->fetch_assoc();
           $Amount = $data_array['amount'];
           $Category = 3;
       }
       $AccountReference = $category;//$_REQUEST['phone_number'];
       $TransactionDesc = $_REQUEST['phone_number'];
       //Capture AccountReference
      /// $jsFile = "M_PESAConfirmationResponse.txt";
        $log1=fopen('jsubFile',"w");
        fwrite($log1, "\n{".$ar."AccountReference".$ar.":".$ar.$AccountReference.$ar."}\n");
        fclose($log1);
        
                // API Constants
        
        $consumerKey = "H6lC1hgPWGF0iPtS0Z4BQpzXGmiQ4MUfy9Aj8kCaGyiQH1X3";
        $consumerSecret = "8XylJ5muPF0GSS5RnOtGTuHqQ8GgmYztTzs42ATx2i4pqBvRalnhciC7raBweirk";
        
        $url = 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

         $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        $credentials = base64_encode($consumerKey.':'.$consumerSecret);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Authorization: Basic '.$credentials)); //setting a custom header
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        $curl_response = curl_exec($curl);

        $token = json_decode($curl_response)->access_token;

        $url2 = 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

       $BusinessShortCode = '4140371';

        $curl2 = curl_init();
        curl_setopt($curl2, CURLOPT_URL, $url2);
        curl_setopt($curl2, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Authorization:Bearer '.$token));
        $timestamp='20'.date(    "ymdhis");
        $password=base64_encode($BusinessShortCode.$passKey.$timestamp);
        $curl_post_data = array(
            //Fill in the request parameters with valid values
            'BusinessShortCode' => '4140371',
            'Password' => $password,
            'Timestamp' => $timestamp,
            'TransactionType' => 'CustomerPayBillOnline',
            'Amount' => $Amount,
            'PartyA' => $PhoneNumber,
            'PartyB' => '4140371',
            'PhoneNumber' => $PhoneNumber,
            'CallBackURL' => 'https://bitstutorconnect.co.ke/packpay/myparse.php',
            'AccountReference' => $AccountReference,
            'TransactionDesc' => $TransactionDesc
        );
        $data_string = json_encode($curl_post_data);

        curl_setopt($curl2, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl2, CURLOPT_POST, true);
        curl_setopt($curl2, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($curl2, CURLOPT_HEADER, false);
        $curl_response2=curl_exec($curl2);

        //print_r($curl_response2);
        return $curl_response2;

    }

    public function receiveCallBack()
    {
           
           // mail('dngwono@gmail.com', 'Stk Push', json_encode($_REQUEST));

        try{


            //Get input stream data and log it in a file
            $payload = file_get_contents('php://input');
            $file = 'subtest.txt'; //Please make sure that this file exists and is writable
            $fh = fopen($file, 'a');
            fwrite($fh, "\n====".$AccountReference."\n====".date("d-m-Y H:i:s")."====\n".$TransactionDesc."====\n");
            fwrite($fh, $payload."\n");
            fclose($fh);
            //chmod($file, 0777); 

            //mail('dngwono@gmail.com', 'Stk Push', $payload);

        }
        catch (\Exception $exception)
        {
            mail('dngwono@gmail.com', 'Stk Push', $exception->getMessage());
        }
    }
    
    public function removeZero()
    {
        
    }
    
}
?>

