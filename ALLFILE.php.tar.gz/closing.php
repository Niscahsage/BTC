<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PHP Page with Refresh/Close Alert</title>
    <script>
        // This function is triggered when the user tries to leave the page
        window.addEventListener('beforeunload', function (e) {
            // Setting a message to the event's returnValue property will trigger the dialog
            var message = "If you leave this page without finishing viewing your lesson, you will not be able to access it unless you pay for it again?";
            e.returnValue = message; // Standard compliant way to show the message
            return message; // For compatibility with some older browsers
        });
    </script>
</head>
<body>
    <h1>Welcome to My PHP Page</h1>
    <p>This page will show an alert if you try to refresh or close the tab.</p>
    
    <!-- PHP code can go here -->
    <?php
        // Your PHP logic here
        echo "<p>This is a PHP-generated message.</p>";
    ?>
</body>
</html>
