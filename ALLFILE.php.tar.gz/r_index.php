<?php ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="icon" type="image/jpeg" href="assets/images/bos.png">

    <title>BTC: Let's learn digitally!</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-onix-digital.css">
    <link rel="stylesheet" href="assets/css/animated.css">
    <link rel="stylesheet" href="assets/css/owl.css">
<style>
.dropbtn {
  background-color: #ff695f;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
.dropdown-backdrop {
    z-index:0;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
  </head>
  <body>

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="index.php" class="logo">
              <img src="assets/images/bos.png">
            </a>

            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li class="scroll-to-section"><a href="#top" class="active">Home</a></li>
              <li class="scroll-to-section"><a href="#services">Services</a></li>
              <li class="scroll-to-section"><a href="#about">About</a></li>
              <!--<li class="scroll-to-section"><a href="#portfolio">Resources</a></li>
              <li class="scroll-to-section"><a href="#video">Sample Classes</a></li>--> 
              <li class="scroll-to-section"><a href="#contact">Contact Us</a></li>
              <li class="scroll-to-section"><a href="subscription.php">Subscribe</a></li>
			  <li class="scroll-to-section"><a href="viewlesson.php">View Lesson</a></li>
              <li class="scroll-to-section"><a href="client">My Account</a></li>
              <li class="scroll-to-section"><div class="dropdown"><button class="dropbtn">Go to Class</button><div class="dropdown-content"><a href="advancedclasses.php">Advanced</a><a href="elementaryclasses.php">Basic</a><a href="juniorclasses.php">JSS</a></div></div></li>
            </ul>
            
            <a class='menu-trigger'>
                <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div class="main-banner" id="top" style="background-color:#ffe7cc">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
            <div class="col-lg-3">
              <div class="owl-carousel owl-banner">
                <div class="item header-text">
                  <h6>Basic/Elementary Learning</h6>
                  <p>
                  Learner access to Basic learning is such a basic need for every child. We however reckon that such access has remained rather elusive to many falling in this bracket.<br/>Some of the most prevalent challenges have been:<br/> &#8211;distances traveled to school,<br/> 
                  &#8211;understaffing in institutions of learning,<br/> &#8211;poverty,<br/> &#8211;hunger, <br/>&#8211;sickness, among others.<br/>
                With these considerations, BTC has provided a portal allowing for every child to access their lessons most conveniently. Below are the subjects BTC has profiled lessons for the elementary learner: Maths, English, Kiswahili, Science, Art and Music at only 40/- per lesson.
                  </p>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="elementaryclasses.php">Click here to go to Class</a>
                    </div>
                  </div>
                </div>
              </div><br/><br/>
            </div>
			  <div class="col-lg-3">
              <div class="owl-carousel owl-banner">
                <div class="item header-text">
                  <h6>JSS Learning</h6>
                  <p>
                   The CBC is a new curriculum largely hinged on competence development and relevance to real-life situations. Reality is; the new curriculum has been received with excitement and panic in equal measure.
Scarcity of tutors and necessary resources notwithstanding, BTC presents you with your most needed bailout in all key CBC learning areas. At our virtual platform (BTC), we offer you up-to-speed tutorial lessons specially presented by our CBC champions most conveniently -digitally!
In the meantime, we are offering tutorials in seven Learning Areas, viz: Mathematics, Integrated Science; Health Educ, Agriculture, Life Skills, Sports & Physical Educ and Home Science.
Kindly click on the on the link below to go to class right away.
                  </p>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="juniorclasses.php">Click here to go to Class</a>
                    </div>
                  </div>
                </div>
              </div><br/><br/>
            </div>
            <div class="col-lg-3">
              <div class="owl-carousel owl-banner">
                <div class="item header-text">
                  <h6>Advanced Learning</h6>
                  <p>
                   Essentially, post elementary learning is what defines the future prospects of the learner. It is no doubt the most crucial stage of ones life.<br/>While the workload at this level can at times be one overbearing, learners often encounter challenges beyond their capabilities. Out of this reality, these learners require an available and versatile support system that will empower them to surmount their performance challenges relating, but not limited to; absenteeism owing to fee challenges, challenging subjects/topics, workload, attitude against teachers, negative effects of the phone/TV, etc.<br/>To mitigate against such drawbacks, BTC has availed makeup lessons in the following learning areas: Math, English Literature, Swahili Fasihi, Biology, Chemistry, Physics at only 50/- per one hour lesson.
                  </p>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="advancedclasses.php">Click here to go to Class</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			  <div class="col-lg-3">
              <div class="owl-carousel owl-banner">
                <div class="item header-text">
                  <h6>School Packages/Home Schoolers</h6>
                  <!--<p>
                      BOS is a digitally enabled learning platform that serves to link learners the best tutors most conveniently, digitally. We exist to ensure unlimited access to curriculum materials for both Basic and Advanced learning.<br/> Our aim is to make learning accessible and affordable to every learner irrespective of their economic background, speed of learning or level of staffing in their schools.<br/>Access to our to our content is rock-bottom cheap, quick and unlimited on every digitally enabled gadget.<br/>Our tutors are all certified teachers sourced from diverse experiences and backgrounds and learners can access their lessons at their most convenience; at home, school, in the car or hospital.<br/>We simply are here to remove any boundaries to good learner-tutor experience!
                  </p>-->
					<p>Bits Tutor Connect enables homeschoolers and schools get access to learning content for their learners with ease and at the cofort of their home or school classes. We exist to ensure unlimited access to curriculum materials for all learners. We strive to make learning material accessible and affordable to every learner irrespective of their economic background, speed of learning or level of staffing in schools. We are simply here to remove any boundaries to good learner-tutor experience!<br/> With an annual membership, Home Schoolers and Schools get access to different learning content packages at affordable rates. Become a member to enjoy the best in our platform.
					</p>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="packages.php">Click here to subscribe</a>
                    </div>
                  </div>
                </div>
              </div><br/><br/>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="services" class="our-services section" style="margin-top: -100px; background-color:#ffe7cc">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 offset-lg-3">
          <div class="section-heading">
            <h2>Our Services</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">
          <div class="owl-carousel owl-services">
            <div class="item">
              <h4>Home Schoolers</h4>
              <div class="icon"><img src="assets/images/service-icon-04.png" alt=""></div>
              <p>Through our quality and educative digital content, learners are able to get the best of every topic in each subject of their choice.</p>
              <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="packages.php">Click here to go to Class</a>
                    </div>
                  </div>
            </div>
            <div class="item">
              <h4>Basic learning content</h4>
              <div class="icon"><img src="assets/images/service-icon-04.png" alt=""></div>
              <p>Select from a range of availble content for your pupil to learn Mathematics, English and Science</p>
              <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="elementaryclasses.php">Click here to go to Class</a>
                    </div>
                  </div>
            </div>
            <div class="item">
              <h4>Advanced learning Content</h4>
              <div class="icon"><img src="assets/images/service-icon-04.png" alt=""></div>
              <p>We have amassed loads of learning content in various subjects like Mathematics, Chemistry, Physics, Biology, English Literature &amp; Kiswahili Fasihi.</p>
              <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="advancedclasses.php">Click here to go to Class</a>
                    </div>
                  </div>
            </div>
            <div class="item">
              <h4>School Packages</h4>
              <div class="icon"><img src="assets/images/service-icon-04.png" alt=""></div>
              <p>Through our quality and educative digital content, learners are able to get the best of every topic in each subject of their choice.</p>
              <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="packages.php">Click here to go to Class</a>
                    </div>
                  </div>
            </div>
            <div class="item">
              <h4>Basic learning content</h4>
              <div class="icon"><img src="assets/images/service-icon-04.png" alt=""></div>
              <p>Select from a range of availble content for your pupil to learn Mathematics, English and Science</p>
              <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="elementaryclasses.php">Click here to go to Class</a>
                    </div>
                  </div>
            </div>
            <div class="item">
              <h4>Advanced learning Content</h4>
              <div class="icon"><img src="assets/images/service-icon-04.png" alt=""></div>
              <p>We have amassed loads of learning content in various subjects like Mathematics, Chemistry, Physics, Biology, English Literature &amp; Kiswahili Fasihi.</p>
              <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="advancedclasses.php">Click here to go to Class</a>
                    </div>
                  </div>
            </div>
            <div class="item">
              <h4>JSS Learning Content</h4>
              <div class="icon"><img src="assets/images/service-icon-04.png" alt=""></div>
              <p>Through our quality and educative digital content, learners are able to get the best of every topic in each subject of their choice.</p>
              <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="juniorclasses.php">Click here to go to Class</a>
                    </div>
                  </div>
            </div>
            <div class="item">
              <h4>Basic learning content</h4>
              <div class="icon"><img src="assets/images/service-icon-04.png" alt=""></div>
              <p>Select from a range of availble content for your pupil to learn Mathematics, English and Science</p>
              <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="elementaryclasses.php">Click here to go to Class</a>
                    </div>
                  </div>
            </div>
            <div class="item">
              <h4>Advanced learning Content</h4>
              <div class="icon"><img src="assets/images/service-icon-04.png" alt=""></div>
              <p>We have amassed loads of learning content in various subjects like Mathematics, Chemistry, Physics, Biology, English Literature &amp; Kiswahili Fasihi.</p>
              <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="advancedclasses.php">Click here to go to Class</a>
                    </div>
                  </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="about" class="about-us section" style="background-color:#ffe7cc">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="section-heading">
            <h2>WHY BTC?!</h2>
            <p>
                The benefits we bring to our client as a learner, parent or teacher are immense:<br/>
            &#8211; Content access at rock-bottom rates <br/>
            &#8211; Quick access to classroom lessons <br/>
            &#8211; most optimal utilization of the phone by our learners <br/>
            &#8211; Encounters with the most professional tutors <br/>
            &#8211; Avoidance of risks associated with commuting for tutorials <br/>
            &#8211; No time wasted commuting for tutorials <br/>
            &#8211; Tutors can equally earn from the platform <br/>
            &#8211; At last a teacher has appeared for the homeschoolers <br/>
                  </p>
                  
          </div>
        </div>
		  <div class="col-lg-6">
          <div class="section-heading">
            <h2>BTC SUBSCRIPTION!</h2>
            <p>
               We are giving you, our clients, an opportunity to enjoy subsidized service delivery on our platform. By making an annual subscription of 250 KES, you get to enjoy rediced charge rates of 40 KES for the Advanced Learning resources and KES 30 for the Basic Learning resouces.
                  </p>
                  
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="subscription.php">Click here to Subscribe</a>
                    </div>
                  </div>
                  
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="contact" class="contact-us section" style="background-color:#ffe7cc">
    <div class="container">
      <div class="row">
        <div class="col-lg-7">
          <div class="section-heading">
            <h2>Get In Touch</h2>
            <div class="info">
				<div><i class="fa fa-phone"></i><i style="color:#000000; font-size:20px">+254 725 701 014</i></div>&nbsp;&nbsp;&nbsp;&nbsp;
              <div><i class="fa fa-envelope"></i> <a style="color:#000000; font-size:20px"  href="mailto:info@bitstutorconnect.co.ke">info@bitstutorconnect.co.ke</a></div>
            </div>
          </div>
        </div>
        <div class="col-lg-5 align-self-center">
          <form id="contact" action="" method="get">
            <div class="row">
              <div class="col-lg-12">
                <fieldset>
                  <input type="name" name="name" id="name" placeholder="Your Name" autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="text" maxlength="10" name="phone" id="phone" placeholder="0722000000" autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="text" name="comment" id="comment" placeholder="Your Comment" required="">
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <button type="submit" id="form-submit" class="main-button">Submit Request</button>
                </fieldset>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <div class="footer-dec" style="background-color:#ffe7cc">
    <img src="assets/images/footer-dec.png" alt="">
  </div>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <div class="about footer-item">
            <div class="logo">
              <a href="#"><img src="assets/images/bos.png" alt="Onix Digital TemplateMo"></a>
            </div>
            <a href="mailto:info@bitstutorconnect.co.ke">info@bitstutorconnect.co.ke</a>
            <ul>
              <li><a href="https://web.facebook.com/BitsOnlineSchool/" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <!--<li><a href="/bitsonlineschool"><i class="fa fa-twitter"></i></a></li>
              <li><a href="/bitsonlineschool"><i class="fa fa-youtube"></i></a></li>-->
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="services footer-item">
            <h4>Services</h4>
            <ul>
              <li><a href="elementaryclasses.php">Elementary Learning Content</a></li>
              <li><a href="advancedclasses.php">Advanced Learning Content</a></li>
				<li><a href="juniorclasses.php">JSS Learning Content</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="community footer-item">
            <h4>More Resources</h4>
            <ul>
              <li><a href="#">Revision Material</a></li>
				<li><a href="userguide.php">User Guide</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="subscribe-newsletters footer-item">
            <h4>Subscribe Newsletters</h4>
            <p>Get our latest news and ideas to your inbox</p>
            <form action="#" method="get">
              <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
              <button type="submit" id="form-submit" class="main-button "><i class="fa fa-paper-plane-o"></i></button>
            </form>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="copyright">
            <p>Copyright © <?php echo date('Y');?> Bits Tutor Connect. All Rights Reserved. 
            <br></p>
          </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Scripts -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/animation.js"></script>
  <script src="assets/js/imagesloaded.js"></script>
  <script src="assets/js/custom.js"></script>

  <script>
  // Acc
    $(document).on("click", ".naccs .menu div", function() {
      var numberIndex = $(this).index();

      if (!$(this).is("active")) {
          $(".naccs .menu div").removeClass("active");
          $(".naccs ul li").removeClass("active");

          $(this).addClass("active");
          $(".naccs ul").find("li:eq(" + numberIndex + ")").addClass("active");

          var listItemHeight = $(".naccs ul")
            .find("li:eq(" + numberIndex + ")")
            .innerHeight();
          $(".naccs ul").height(listItemHeight + "px");
        }
    });
  </script>
</body>
</html>