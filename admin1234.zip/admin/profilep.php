<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beautiful Web Page</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #ffffff; /* white */
            color: #333333; /* dark gray */
        }
        header {
            background-color: #6ab04c; /* green */
            padding: 20px;
            text-align: center;
            color: #ffffff; /* white */
        }
        nav {
            background-color: #ffffff; /* white */
            padding: 10px;
            text-align: center;
        }
        nav a {
            text-decoration: none;
            color: #333333; /* dark gray */
            padding: 10px;
        }
        section {
            padding: 20px;
        }
        footer {
            background-color: #6b5b95; /* purple */
            color: #ffffff; /* white */
            padding: 20px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
		
		.topnav {
  overflow: hidden;
}
		
    </style>
</head>
<body>
    <header>
        <div class="topnav">
	<div class="logo">
		<img src="logo.png" alt="Logo" width="70px" height="50px"></div>

  <a href="index.php" class="active">Home</a>
  <a href="about.php">About Us</a>
  <a href="resources.php">Resources</a>
  <a href="prayers.php">Prayers</a>
  <a href="donate.php">Donate</a>
  <a href="contact.php">Contact Us</a>
  <a href="myaccount.php">My Account</a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
		<div class="search" style="margin-top:10px;">
    <input type="text" placeholder="Search">
    <button type="submit">Search</button>
  </div>
</div>
    </header>

    <nav>
      
		<div  align="center" style="background-image: url('pray.jpg'); background-size:cover ; height:400px; margin-top:75px;  margin-left:500px; margin-right:500px; ">
			<form action="profilep.php" method="post" enctype="multipart/form-data">
  Select image to upload:
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload Image" name="submit">
</form>
		</div>
		
    </nav>
    
    <footer>
<p><hr><p/>
    </footer>
</body>
</html>



		<?php
$target_dir = "ALLUPLOADS/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$file_link ="https://paydebttechsystems.co.ke/catholiccafe/ALLUPLOADS/". basename($_FILES["fileToUpload"]["name"]);

// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    echo "File is not an image.";
    $uploadOk = 0;
  }
}

// Check if file already exists
if (file_exists($target_file)) {
  echo "Sorry, file already exists.";
  $uploadOk = 0;
}

// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
  echo "Sorry, your file is too large.";
  $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
	  // Add database connection code
	 $servername = "localhost";
        $username = "zukbitso_paydebt";
        $password = "cpUzGfiJ+5g~";
        $database ="zukbitso_paydebtdb";
	  $conn = mysqli_connect($servername,$username,$password,$dbname);
	  //sql to insert the field records
	  
   

    

    // query to insert into the table

    $sql = "INSERT INTO school_employees (file_name) VALUES ('$file_link' )";
    if($conn->query($sql) === TRUE){
        echo "Record was created successfully";
    }
    
	  
	  // execute query and echo success message
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
}
?>
   
		   
