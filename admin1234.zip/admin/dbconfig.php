<?Php
/////// Update your database login details here /////
$host_name = "localhost"; // Your host name 
$database = "zukbitso_paydebtdb";       // Your database name
$username = "zukbitso_paydebt";            // Your login userid 
$password = "cpUzGfiJ+5g~";            // Your password 
//////// End of database details of your server //////

//////// Do not Edit below /////////
$connection = mysqli_connect($host_name, $username, $password, $database);

if (!$connection) {
    echo "Error: Unable to connect to MySQL.<br>";
    echo "<br>Debugging errno: " . mysqli_connect_errno();
    echo "<br>Debugging error: " . mysqli_connect_error();
    exit;
}
?>