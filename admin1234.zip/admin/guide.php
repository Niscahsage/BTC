<?php
 header('Access-Control-Allow-Origin: *'); 
    header("Access-Control-Allow-Credentials: true");
    header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');//  
    header('Access-Control-Max-Age: 1000');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
   $params = file_get_contents('php://input');
    
    //echo "<script>document.location='paid.php'</script>";
    
               //Connect to MSSQL
               
        $servername = "localhost";
        $username = "zukbitso_paydebt";
        $password = "cpUzGfiJ+5g~";
        $database ="zukbitso_paydebtdb";

       $Guide =$_REQUEST['guide'];
       
       // Create connection
        $conn = new mysqli($servername, $username, $password,$database);

    	$sql = "UPDATE userguide set guide='$Guide' WHERE id=1";

        
            if ($conn->query($sql) === TRUE) 
            {
                echo "<script>alert('User Guide has been updated Successfully');</script>";
				echo "<script>document.location='index.php'</script>";
            }
            else
            {
			echo "<script>alert('Failed to update User Guide. Try again!');</script>";
				echo "<script>document.location='index.php'</script>";
            }


            ?>