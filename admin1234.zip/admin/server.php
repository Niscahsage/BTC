<?php
session_start();

// initializing variables
//$username = "";
//$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'zukbitso_paydebt', 'cpUzGfiJ+5g~', 'zukbitso_paydebtdb');

/**
 * mysql_connect is deprecated
 * using mysqli_connect instead
 */
/*
$databaseHost     = 'localhost';
$databaseName     = 'boo';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
*/


// REGISTER USER


// ... 

// LOGIN USER


?>