<?php
  // Include database connection file
  //include_once('dbconfig.php');
  if (isset($_POST['submit'])) {
	  $servername = "localhost";
	  $username = "zukbitso_paydebt";
	$password = "cpUzGfiJ+5g~";
	$dbname = "zukbitso_paydebtdb";
	  
	  // Create connection
$con = new mysqli($servername, $username, $password, $dbname);
	  
	  function GenerateSerial()
            {
                $chars = array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
                $sn = '';
                $max = count($chars) - 1;
                for ($i = 0; $i < 4; $i++) {
                    $sn .= (!($i % 2) && $i ? 'EBOS' : '') . $chars[rand(0, $max)];
                }
             return $sn;
            }
    $cde = GenerateSerial();
	$link = "https://paydebttechsystems.co.ke/bitsonlineschool/learninganalysis.php?resVal='$cde'";
    $username = $con->real_escape_string($_POST['username']);
    $password = $con->real_escape_string(md5($_POST['password']));
    $name     = $con->real_escape_string($_POST['name']);
    $role     = $con->real_escape_string($_POST['role']);
	$code     = $con->real_escape_string($cde);
	$mktlink     = $con->real_escape_string($link);
    $query  = "INSERT INTO admins (name,username,password,role,code,marketinglink) VALUES ('$name','$username','$password','$role','$code','$mktlink')";
    $result = $con ->query($query);
    if ($result==true) {
      header("Location:index.php");
      die();
    }else{
      $errorMsg  = "You are not Registred..Please Try again";
    }   
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bits Online School - Employee</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>
<body>
<div class="card text-center" style="padding:20px;">
  <h3>Bits Online School - Employee</h3>
</div><br>
<div class="container">
  <div class="row">
    <div class="col-md-3"></div>
      <div class="col-md-6">      
        <?php if (isset($errorMsg)) { ?>
          <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo $errorMsg; ?>
          </div>
        <?php } ?>
        <form action="" method="POST">
          <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" name="name" placeholder="Enter Name" required="">
          </div>
          <div class="form-group">  
            <label for="username">Username:</label>
            <input type="text" class="form-control" name="username" placeholder="Enter Username" required="">
          </div>
          <div class="form-group">  
            <label for="password">Password:</label>
            <input type="password" class="form-control" name="password" placeholder="Enter Password" required="">
          </div>
          <div class="form-group">  
            <label for="role">Role:</label>
            <select class="form-control" name="role" required="">
              <option value="">Select Role</option>
              <option value="super_admin">Super admin</option>
              <option value="admin">Admin</option>
              <option value="manager">Manager</option>
            </select>
          </div>
          <div class="form-group">
            <!--<p>Already have account ?<a href="login.php"> Login</a></p>-->
            <input type="submit" name="submit" class="btn btn-primary">
          </div>
        </form>
      </div>
  </div>
</div>
</body>
</html>