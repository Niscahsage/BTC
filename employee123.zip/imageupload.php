<?php
session_start();
// this file recieves the posted values from signup.php, connects to the database and inserts the data into the table

//First allow all headers and cross origins
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Accesol-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Authorization');
$params = file_get_contents('php://input');


    if (isset($_POST['form-submit']))
   {
	    $servername = "localhost";
        $username = "zukbitso_paydebt";
        $password = "cpUzGfiJ+5g~";
        $database ="zukbitso_paydebtdb";
	$conn = new mysqli($servername,$username,$password,$dbname);
    // declare variables to hold the posted values
	$name = $con->real_escape_string($_POST['name']);
    $email =   $con->real_escape_string($_POST['email_address']);
    $phone_number = $con->real_escape_string($_POST['phone_number']);
    $email_address = $con->real_escape_string ($_POST['emailaddress']);
   $company_name =  $con->real_escape_string($_POST['company_name']);
   $alt_number = $con->real_escape_string($_POST['alt_number']);
    $address = $con->real_escape_string($_POST['address']);
   $id_number = $con->real_escape_string($_POST['id_number']);
	$mailMess = "Dear $name , 
Thank you for joining Catholic Cafe. Kindly take time to have a look at our informative resources about the Catholic Faith and general Christian values using the link https://paydebttechsystems.co.ke/catholiccafe/resources.php
Best Regards,
Linkpal Team";

    

    // query to insert into the table

    $sql = "INSERT INTO lawyer_tbl (name,email_address,phone_number,company_name,alt_contact,address) VALUES ('$name','$','$email_address','$phone_number','$company_name,'$alt_number','$address')";
    if($conn->query($sql) === TRUE){
                    $pdf_target_dir = "https://paydebttechsystems.co.ke/assets/images/";
              $aboutself_file = $pdf_target_dir . str_replace(" ", "", strtolower(basename($_FILES["aboutself"]["name"])));
              $aboutself_file_link = "https://paydebttechsystems.co.ke/assets/images/" . str_replace(" ", "", strtolower(basename($_FILES["aboutself"]["name"])));
              move_uploaded_file($_FILES["aboutself"]["tmp_name"], $aboutself_file);
       /*     $query = "UPDATE tblusers set aboutself='".$aboutself_file_link."' WHERE id='".$profile->id."'";
            
            if(mysqli_query($conn, $query)){
                echo "You have uploaded your profile successfully";
            }
            else{
                echo "Error estbalishing a connection to the database. Please contact support for more information.";
            
    }*/
		
    else{
        echo "Your data was not recorded. Please try again later!";
    }
   }

?>
<?php
//$mess=  $_SESSION["massage"];

mail($email_address,'Wecome to Catholic Cafe',$mailMess);

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
	  <link rel="icon" type="image/jpeg" href="/accets/images/paylogo.png">

    <title>Pay Debt Tech Systems</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="accets/css/fontawesome.css">
    <link rel="stylesheet" href="accets/css/templatemo-onix-digital.css">
    <link rel="stylesheet" href="accets/css/animated.css">
    <link rel="stylesheet" href="accets/css/owl.css">
<!--

TemplateMo 565 Onix Digital

https://templatemo.com/tm-565-onix-digital

-->
  </head>

<body>

  <!-- ***** Preloader Start   style="background-color: #FFE5B4" ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="index.php" class="logo">
              <img src="accets/images/paylogo.png">
            </a>
            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li class="scroll-to-section"><a href="#top" class="active">HOME</a></li>
              <li class="scroll-to-section"><a href="https://paydebttechsystems.co.ke">ABOUT US</a></li>
              <li class="scroll-to-section"><a href="https://paydebttechsystems.co.ke">PRICING</a></li> 
              <li class="scroll-to-section"><a href="https://paydebttechsystems.co.ke">CONTACT</a></li> 
              <li class="scroll-to-section"><div class="main-blue-button-hover"><a href="https://paydebttechsystems.co.ke/debtype.php">CLAIM DEBT</a></div></li> 
            </ul>        
            <a class='menu-trigger'>
                <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div id="contact" class="contact-us section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 align-self-center">
          <form id="contact" action="" method="POST">
            <div class="row">
              <div class="col-lg-12">
                <fieldset>
                  <input type="name" name="name" id="name" placeholder="Enter your Name" autocomplete="on" required>
                </fieldset>
              </div>
				 <div class="col-lg-12">
                <fieldset>
                  <input type="text" name="address" id="address" placeholder="Enter your Address" autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="number"  name="phone_number" id="phone_number" placeholder="Your Phone Number in format 254721******" autocomplete="on" maxlength="10" required>
                </fieldset>
              </div>
      
              <div class="col-lg-12">
                <fieldset>
                  <input type="number"  name="alt_contact" id="alt_number" placeholder="Alternative Phone Number in format 254721******" autocomplete="on" maxlength="10" required>
                </fieldset>
              </div>
				<div class="col-lg-12">
                <fieldset>
                  <input type="text" name="id_number" id="id_number" placeholder="Your id number e.g 11223344" required="">
                </fieldset>
              </div>
<div class="col-lg-12">
                <fieldset>
                  <input type="text" name="email_address" id="email_address" placeholder="Email Address e.g john@gmail.com" required="">
                </fieldset>
              </div>				
              <div class="col-lg-12">
                <fieldset>
                  <input type="text" name="company_name" id="company_name" placeholder="Company name" required="">
                </fieldset>
              </div>
           <!--   <div>
                  <input type="checkbox" name="indemnity" id="indemnity" style="width: 35px; height:35px" value="I declare that this is my SMS to my debtor and thus PAYDEBT TECHNOLOGIES is in no way responsible for it" required="true">
                  <label for="indemnity" style="float-left:-5px; float-top:-7px">Indemnity: I declare that this is my SMS to my debtor and thus PAYDEBT TECHNOLOGIES is in no way responsible for it.</label>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <div>
                      <p><b>If you click submit request, Shortly you will receive an M-PESA prompt on your phone requesting you to enter your M-PESA PIN to make your payment. Please ensure your phone is on and unlocked to enable you to complete the process. Thank you.</b></p>
                  </div><br/>
                </fieldset>
              </div>-->
              <div class="col-lg-12">
                <fieldset>
                  <button type="submit" >Register</button>
                </fieldset>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="contact-dec">
      <img src="accets/images/contact-dec.png" alt="">
    </div>
    <div class="contact-left-dec">
      <img src="accets/images/contact-left-dec.png" alt="">
    </div>
  </div>

  <div class="footer-dec">
    <img src="accets/images/footer-dec.png" alt="">
  </div>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <div class="about footer-item">
            <div class="logo">
              <!--<a href="https://paydebttechsystems.co.ke/claim.php"><img src="accets/images/favicon.png" alt="Onix Digital TemplateMo"></a>-->
            </div>
            <a href="https://paydebttechsystems.co.ke">info@paydebttechsystems.co.ke</a>
            <ul>
              <li><a href="https://web.facebook.com/PayDebtTechnologies" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <!--<li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-instagram"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fa fa-skype"></i></a></li>-->
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="services footer-item">
            <h4>Useful Links</h4>
            <ul>
              <li><a href="https://paydebttechsystems.co.ke">Home</a></li>
              <li><a href="https://paydebttechsystems.co.ke">About US</a></li>
              <li><a href="https://paydebttechsystems.co.ke">Pricing</a></li>
              <li><a href="https://paydebttechsystems.co.ke">Terms of Service</a></li>
              <li><a href="https://paydebttechsystems.co.ke">Privacy Policy</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="community footer-item">
            <h4>Our Services</h4>
            <ul>
              <li><a href="https://paydebttechsystems.co.ke/claim.php">Debt Reminder</a></li>
              <li><a href="https://paydebttechsystems.co.ke/claim.php">Debt Education</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="subscribe-newsletters footer-item">
            <h4>Our Newsletter</h4>
            <p>Get our latest news and ideas</p>
            <form action="#" method="get">
              <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
              <button type="submit" id="form-submit" class="main-button "><i class="fa fa-paper-plane-o"></i></button>
            </form>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="copyright" style="font-style: bold; color: black">
            <p><b>Copyright © <?php echo date('Y'); ?> PAYDEBT. All Rights Reserved. </b></p>
          </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Scripts -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="accets/js/owl-carousel.js"></script>
  <script src="accets/js/animation.js"></script>
  <script src="accets/js/imagesloaded.js"></script>
  <script src="accets/js/custom.js"></script>

  <script>
  // Acc
    $(document).on("click", ".naccs .menu div", function() {
      var numberIndex = $(this).index();

      if (!$(this).is("active")) {
          $(".naccs .menu div").removeClass("active");
          $(".naccs ul li").removeClass("active");

          $(this).addClass("active");
          $(".naccs ul").find("li:eq(" + numberIndex + ")").addClass("active");

          var listItemHeight = $(".naccs ul")
            .find("li:eq(" + numberIndex + ")")
            .innerHeight();
          $(".naccs ul").height(listItemHeight + "px");
        }
    });
  </script>
</body>
</html>