<?php
 //session_start();
 //session_destroy();
 //session_unset($_SESSION['NAME']);
 //session_unset($_SESSION['ROLE']);
 //session_unset($_SESSION['ID']);
 //header("Location:login.php");
 //die();

// Before deleting session, first recreate session
session_start();

// Destroy all session data to logout
session_destroy();

// Redirect to login page after logout
header("location: login.php");
?>