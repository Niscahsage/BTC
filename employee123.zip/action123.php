<?php 
session_start();
$uid = $_SESSION['ID'];
// this file recieves the posted values from signup.php, connects to the database and inserts the data into the table

//First allow all headers and cross origins
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Accesol-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Authorization');
$params = file_get_contents('php://input');


   $servername = "149.56.96.102";
$username = "bitstuto_zukbits";
$password = "5c{EBU!VoHUm";
$dbname = "bitstuto_schooldb";

//var_dump($servername, $username, $password, $dbname);

$conn = mysqli_connect($servername, $username, $password, $dbname);
    // declare variables to hold the posted values
    $name = $_REQUEST['name'];
    $Email= $_REQUEST['email'];
    $Phonenumber= $_REQUEST['phonenumber'];
    $NSSF= $_REQUEST['NSSF'];
    $NHIF= $_REQUEST['NHIF'];
    $Residence= $_REQUEST['residence']; 
    

    // query to insert into the table

    $sql = "UPDATE school_employees  SET name='$name', Email_Address='$Email' ,Phonenumber='$Phonenumber',NSSF='$NSSF',NHIF='$NHIF',residence='$Residence' WHERE id=$uid";
;
    if($conn->query($sql) === TRUE){
        echo "well";
    }
    else{
        echo "Your data was not recorded. Please try again later!";
    }
?>