<?php
session_start();
// Include database connection file
include_once('config.php');
$uid = $_SESSION['ID'];
if (!isset($_SESSION['ID'])) {
    header("Location:login.php");
    //exit();
}

  if (isset($_POST['submit'])) {
	  // Create connection	  
    $Residence = $con->real_escape_string($_POST['residence']);
    $query  = "UPDATE school_employees set residence='$Residence' WHERE id='$uid'";
    $result = $con ->query($query);
    if ($result==true) {
      header("Location:profile.php");
      die();
    }else{
		header("Location:dashboard.php");
      //$errorMsg  = "Your profile was not updated..Please Try again";
    }   
  }

?>



<style type="text/css">
    .nav-link{
 color: #f9f6f6;
 font-size: 14px;
    } 
	
.blue-button {
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border: none;
            border-radius: 4px;
            transition-duration: 0.4s;
        }	
	
</style>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> profile </title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
       <body>
     <nav class="navbar navbar-info sticky-top bg-info flex-md-nowrap p-10">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="" style="color: #5b5757;"><b>Bits Tutor Connect</b></a>
             <ul class="navbar-nav px-3">
   <li class="nav-item text-nowrap">
           <a class="nav-link" href="logout.php">Hi, <?php echo ucwords($_SESSION['NAME']); ?> Log out</a>
   </li>
      </ul>
  </nav>  
  <div class="container-fluid">
      <div class="row">
   <nav class="col-md-2 d-none d-md-block bg-info sidebar" style="height: 569px">
           <div class="sidebar-sticky">
           <ul class="nav flex-column" style="color: #5b5757;">
        <li class="nav-item">
     <a class="nav-link active" href="dashboard.php">
     <span data-feather="home"></span>
                Dashboard <span class="sr-only">(current)</span>
     </a>
        </li>
    <?php if($_SESSION['ROLE'] == 'super_admin'){ ?>
    <h6>Sales & Subscriptions</h6> 
        <li class="nav-item">
     <a class="nav-link" href="">
             <span data-feather="users"></span>
         Sales
     </a>
        </li> 
        <li class="nav-item">
            <a class="nav-link" href="">
         <span data-feather="users"></span>
         Subscriptions
     </a>
        </li>
        <li class="nav-item">
     <!--<a class="nav-link" href="">
             <span data-feather="users"></span>
         Purchases
     </a>-->
        </li>
    <?php } ?>
    <?php if ($_SESSION['ROLE'] == 'admin' || $_SESSION['ROLE'] == 'Super Admin' || $_SESSION['ROLE'] == 'manager') { ?>
    <h6>Catalog</h6>  
        <li class="nav-item">
     <a class="nav-link" href="">
         <span data-feather="users"></span>
         Products
     </a>
        </li>
        <li class="nav-item">
     <a class="nav-link" href="">
             <span data-feather="users"></span>
         Category
     </a>
        </li> 
        <h6>Order & Shipping</h6>
     <li class="nav-item">
             <a class="nav-link" href="">
             <span data-feather="users"></span>
      Shipping
         </a>
     </li>
     
     <li class="nav-item">
         <a class="nav-link" href="">
             <span data-feather="users"></span>
      Customers
         </a>
     </li>
     <li class="nav-item">
         <a class="nav-link" href="">
      <span data-feather="users"></span>
      Order
         </a>
     </li> 
		<li class="nav-item">
     <a class="nav-link" href="profile.php">
             <span data-feather="users"></span>
         Profile
     </a>
        </li> 	 	   
    <?php } ?>      
       </ul>
   </div>
      </nav>
  <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3">
      <h1 class="h2">Dashboard</h1>
  </div>
  <div class="table-responsive">
    <table class="table table-striped">
      <thead>
         
	  
      
		
     
    
	  
	  
	  
	 
	  
	  <!--<th>Photo</th>
	  <th>NSSF</th>
	  <th>Residence</th>		 
      <th>Created</th>-->
   
      </thead>
      <tbody>
   <?php
           if ($_SESSION['file_link'] == "super_admin") {
    $query = "SELECT * FROM admins";
       }else{
    $file_link = $_SESSION['file_link'];
    $query = "SELECT * FROM school_employees WHERE id = '$uid'";
       }
           $result = $con->query($query);
    if ($result->num_rows > 0) {
           while ($row = $result->fetch_array()) {
       ?>  
      
		   
		   
		   
		   
		   

	 <tr>	   
		   
		   
		   <form action="" method="POST">
		   <label for="name">Name:</label> 	   	   
	<input type="text" name="name" id="name" value="<?php echo $row['name'] ?>" required/><br>
		   
		   
		   
		   
		  
	       <label for="email">Email:</label> 	   	   
	<input type="text" name="email" id="email" value="<?php echo $row['Email_Address'] ?>" required/><br>
		   

		   
<label for="phonenumber">Phone Number:</label> 	   	   
	<input type="int" name="phonenumber" id="phonenumber" value="<?php echo $row['Phonenumber'] ?>" required/><br>		   
		   
		   
		   
	
	       <label for="NSSF">NSSF:</label> 	   	   
	<input type="text" name="NSSF" id="NSSF" value="<?php echo $row['NSSF'] ?>" required/><br>	   
		   
	
		   
<label for="NHIF">NHIF:</label> 	   	   
	<input type="text" name="NHIF" id="NHIF" value="<?php echo $row['NHIF'] ?>" required/><br>	
		   
		   
	<label for="residence">Residence:</label> 	   	   
	<input type="text" name="residence" id="residence" value="<?php echo $row['residence'] ?>" required/><br>	   
		   
		<label for="marketinglink">Marketing Link:</label> 	   	   
	<input type="text" name="marketinglink" id="marketinglink" value="<?php echo $row['marketinglink'] ?>" required/><br>
		   
		   <label for="code">Code:</label> 	   	   
	<input type="text" name="code" id="code" value="<?php echo $row['code'] ?>" required/><br>	
			   
			   <Button type="submit" name="submit" id="submit" >Update</Button>
		   
		    </form>
		   
		      
		  
		    
		   
		   
		   
		   
		   
		   
		  
			 
		  
    
	
	
	
	   
    
	<td><?php echo $row['profile_picture']?></td>
	
       </tr>
          <?php }
   }else{
       echo "<h2>No record found!</h2>";
   } ?>         
   </tbody>
      </table>
  </div>
     </main>
 </div>
    </div>  
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    feather.replace();
</script>
		   <script>
			   function upprof()
			   {
				   alert("I have been clicked!!");
			   }
		   </script>
</body>
</html>




