<?php
session_start();
// Include database connection file
include_once('config.php');
$uid = $_SESSION['ID'];
if (!isset($_SESSION['ID'])) {
    header("Location:login.php");
    exit();
}
?>
<style type="text/css">
    .nav-link{
 color: #f9f6f6;
 font-size: 14px;
    } 
	
.blue-button {
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border: none;
            border-radius: 4px;
            transition-duration: 0.4s;
        }	
	
</style>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> profile </title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
       <body>
     <nav class="navbar navbar-info sticky-top bg-info flex-md-nowrap p-10">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="" style="color: #5b5757;"><b>Bits Tutor Connect</b></a>
             <ul class="navbar-nav px-3">
   <li class="nav-item text-nowrap">
           <a class="nav-link" href="logout.php">Hi, <?php echo ucwords($_SESSION['NAME']); ?> Log out</a>
   </li>
      </ul>
  </nav>  
  <div class="container-fluid">
      <div class="row">
   <nav class="col-md-2 d-none d-md-block bg-info sidebar" style="height: 569px">
           <div class="sidebar-sticky">
           <ul class="nav flex-column" style="color: #5b5757;">
        <li class="nav-item">
     <a class="nav-link active" href="dashboard.php">
     <span data-feather="home"></span>
                Dashboard <span class="sr-only">(current)</span>
     </a>
        </li>
    <?php if($_SESSION['ROLE'] == 'super_admin'){ ?>
    <h6>Sales & Subscriptions</h6> 
        <li class="nav-item">
     <a class="nav-link" href="">
             <span data-feather="users"></span>
         Sales
     </a>
        </li> 
        <li class="nav-item">
            <a class="nav-link" href="">
         <span data-feather="users"></span>
         Subscriptions
     </a>
        </li>
        <li class="nav-item">
     <!--<a class="nav-link" href="">
             <span data-feather="users"></span>
         Purchases
     </a>-->
        </li>
    <?php } ?>
    <?php if ($_SESSION['ROLE'] == 'admin' || $_SESSION['ROLE'] == 'Super Admin' || $_SESSION['ROLE'] == 'manager') { ?>
    <h6>Catalog</h6>  
        <li class="nav-item">
     <a class="nav-link" href="">
         <span data-feather="users"></span>
         Products
     </a>
        </li>
        <li class="nav-item">
     <a class="nav-link" href="">
             <span data-feather="users"></span>
         Category
     </a>
        </li> 
        <h6>Order & Shipping</h6>
     <li class="nav-item">
             <a class="nav-link" href="">
             <span data-feather="users"></span>
      Shipping
         </a>
     </li>
     
     <li class="nav-item">
         <a class="nav-link" href="">
             <span data-feather="users"></span>
      Customers
         </a>
     </li>
     <li class="nav-item">
         <a class="nav-link" href="">
      <span data-feather="users"></span>
      Order
         </a>
     </li> 
		<li class="nav-item">
     <a class="nav-link" href="profile.php">
             <span data-feather="users"></span>
         Profile
     </a>
        </li> 	 	   
    <?php } ?>      
       </ul>
   </div>
      </nav>
  <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3">
      <h1 class="h2">Dashboard</h1>
  </div>
  <div class="table-responsive">
    <table class="table table-striped">
      <thead>
         
	  
      
		
     
    
	  
	  
	  
	 
	  
	  <!--<th>Photo</th>
	  <th>NSSF</th>
	  <th>Residence</th>		 
      <th>Created</th>-->
   
      </thead>
      <tbody>
   <?php
           
    $query = "SELECT * FROM school_employees WHERE id = '$uid'";
       
           $result = $conn->query($query);
    if ($result->num_rows > 0) {
           while ($row = $result->fetch_array()) {
       ?>  
       <tr>
		   <p style="font-size:26px;font-style:bold;"> Name : <?php echo $row['name'];?>  </p> 
		  <!-- <div style="float:right; margin-right:40px;" onclick="upprof()">
		   <img src="{getImage.php?id=$uid}" alt="profile"/>
		   </div>-->
		   
		   
		   
		  
		   
		   
  <p style="font-size:26px;font-style:bold;"> Email Address : <?php echo $row['Email_Address'];?>  </p> 
		   <p  style="font-size:26px;font-style:bold"> Phonenumber :<?php echo $row['Phonenumber'];?> </p>
		<p style="font-size:26px; font-style:bold">Code:<?php echo $row['code'];?> &nbsp; &nbsp;&nbsp; NSSF :<?php echo $row['NSSF'];?></p>
		   <p style="font-size:26px; font-style:bold">NHIF:<?php echo $row['NHIF']?> &nbsp; &nbsp;&nbsp; Residence :<?php echo $row['residence']?></p>
		   <p style="font-size:26px; font-style:bold">Marketing link :<?php echo $row['marketinglink']?> </p>
		    
		   
		   
		   
		   
		   
		   
		   
			   <style>
			   .blue-button{
				   text-decoration: none;
				   }
				   .blue-button:hover{
					   text-decoration:none;
				   }
		   </style>
		   <div style="float:right; margin-right:40px;" >
        <a href="profileedit.php" class="blue-button">Edit</a>

		       </div>
		  
    
	
	
	
	   
    
	<td></td>
	
       </tr>
          <?php }
   }else{
       echo "<h2>No record found!</h2>";
   } ?>         
   </tbody>
      </table>
  </div>
     </main>
 </div>
    </div>  
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    feather.replace();
</script>
		   <script>
			   function upprof()
			   {
				   alert("I have been clicked!!");
			   }
		   </script>
</body>
</html>