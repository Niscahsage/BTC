<?php
  // Include database connection file
      header("Location:login.php");
      die();   
?>