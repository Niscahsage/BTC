<?php 
//Connect to MSSQL
$servername = "149.56.96.102";
$username = "bitstuto_zukbits";
$password = "5c{EBU!VoHUm";
$database = "bitstuto_schooldb";
$response = file_get_contents('php://input');
//$data = json_decode(file_get_contents('php://input'), true);
$data = json_decode($response,true);

$MerchantRequestID=$data['Body']['stkCallback']['MerchantRequestID'];
$CheckoutRequestID=$data['Body']['stkCallback']['CheckoutRequestID'];
$ResultCode=$data['Body']['stkCallback']['ResultCode'];
$ResultDesc=$data['Body']['stkCallback']['ResultDesc'];

$Amount=$data['Body']['stkCallback']['CallbackMetadata']['Item'][0]['Value'];
$MpesaReceiptNumber=$data['Body']['stkCallback']['CallbackMetadata']['Item'][1]['Value'];
$TransactionDate=$data['Body']['stkCallback']['CallbackMetadata']['Item'][3]['Value'];
$PhoneNumber=$data['Body']['stkCallback']['CallbackMetadata']['Item'][4]['Value'];
$Processed = '1';

$date = date_create($TransactionDate);
date_add($date, date_interval_create_from_date_string("365 days"));
$EndDate = '20'.date_format($date, "ymdhis");

// Create connection
$conn = new mysqli($servername, $username, $password,$database);

        function GenerateSerial()
            {
                $chars = array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
                $sn = '';
                $max = count($chars) - 1;
                for ($i = 0; $i < 4; $i++) {
                    $sn .= (!($i % 2) && $i ? 'BTC' : '') . $chars[rand(0, $max)];
                }
             return $sn;
            }

        $UserCode = GenerateSerial();
        
$sql = "UPDATE subscriptions set MpesaReceiptNumber='$MpesaReceiptNumber',TransactionDate='$TransactionDate',RequestDate='$TransactionDate',StartDate='$TransactionDate',EndDate='$EndDate',UserCode='$UserCode',Processed='$Processed' WHERE MerchantRequestID='$MerchantRequestID' && CheckoutRequestID='$CheckoutRequestID'";

if($ResultCode == 0 || $ResultCode == '0'){
    //operation was successful->insert to db
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
        
        //upon successful insert into db->post successful.txt
        $log1=fopen('successful',"w");
        fwrite($log1,$response);
        fclose($log1);

        mail('dngwono@gmail.com', 'Mpesa Payment Confirmation', $response);
        mail('nzukipk@gmail.com', 'Mpesa Payment Confirmation', $response);
        
        // send text message
        
        $sqlqry = "SELECT Name,PhoneNumber,UserCode FROM subscriptions WHERE MerchantRequestID='$MerchantRequestID' && CheckoutRequestID='$CheckoutRequestID'";

  $sendDtls = $conn->query($sqlqry);
  $data_array = $sendDtls->fetch_assoc();
  
  $Messg = 'Thank you '.$data_array['Name'].' for subscribing to BTC! Use your Code '.$data_array['UserCode'].' and your phone number to access our services at subsidized rates.';
        
    require_once('smsEndpoint.php');
    $debtsms = (new SENDSMS())->single($data_array['PhoneNumber'],$Messg);
// $collsms = (new SENDSMS())->single($data_array['PhoneNumber'],$data_array['CollMessg']);
    }
    
}
else{
    //stkpush payment not successful _>post unsuccessful.txt
    echo "An error occurred, please try again";
    $log2=fopen('unsuccessful',"a");
    fwrite($log2, "\n\n=================".date("d-m-Y H:i:s")."=================\n");
    fwrite($log2,$response);
    fclose($log2);
}



$log=fopen('all_replies',"a");
fwrite($log, "\n\n=================".date("d-m-Y H:i:s")."=================\n");
fwrite($log,$response);
fclose($log);

?>