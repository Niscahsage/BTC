<?php
class SENDSMS{
   /* public function _construct(){
        $this-> username = "sandbox";
        $this-> apikey = "25b9cca0b2e19a4c486f3ea0bc2d4a575350906a044d77696ddd26546d7711c3";
        $this-> gateway = new AfricasTalkingGateway($this-> username,$this-> apikey,"sandbox");
        $recipients = "+254721850599";
        $message = "Stand up straight with your shoulders straight.";
        $results = $this->gateway->sendMessage($recipients, $message);
    }*/
    
    public function single($Msisdn,$msg)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.mobilesasa.com/v1/send/message',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>'{
            "senderID": "PAYDEBT",
            "message": "'.$msg.'",
            "phone": "'.$Msisdn.'"
        }',
        CURLOPT_HTTPHEADER => array(
            'Accept: application/json',
            'Content-Type: application/json',
            'Authorization: Bearer UkuwPP9mo0gAsAFZlDgLVjPGJGHVqPXEzPe2c5ODa3bvOecO2t86A9utUEg0'
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);

    }
}
?>